"""
unet3d.py

Author: WLLCAS004
Date: July 4, 2024

Description:
This script defines the architecture for a 3D U-Net model designed for medical image segmentation tasks. 
The model leverages NVIDIA's optimised U-Net implementation for 3D volumetric data. The key components 
include convolutional blocks with Instance Normalization, Leaky ReLU activation, and transposed convolution 
for upsampling. The network is fully constructed to operate on 3D data, making it suitable for applications 
like brain tumor segmentation in MRI scans.

Citations:
    - Segment Anything Model (SAM)
    - BraTS Intracranial Meningioma 2023 Challenge Dataset
    - PyTorch libraries
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/models/unet3d.py
"""

import torch
import torch.nn as nn

# Define a convolutional block with Instance Normalisation and LeakyReLU activation. 
class conv_block(nn.Module):
    def __init__(self,ch_in,ch_out1,ch_out2,k1,k2,s1,s2):
        """
        Initialises a convolutional block with two 3D convolutions,
        each followed by Instance Normalization and LeakyReLU activation.

        Args:
        - ch_in: Input channel size.
        - ch_out1: Output channel size after the first convolution.
        - ch_out2: Output channel size after the second convolution.
        - k1: Kernel size for the first convolution.
        - k2: Kernel size for the second convolution.
        - s1: Stride for the first convolution.
        - s2: Stride for the second convolution.
        """
        super(conv_block,self).__init__()
        self.conv = nn.Sequential(
            nn.InstanceNorm3d(ch_in),
            nn.Conv3d(ch_in, ch_out1, kernel_size=k1,stride=s1,padding=1,bias=True),
            nn.LeakyReLU(inplace=True),
            nn.InstanceNorm3d(ch_out1),
            nn.Conv3d(ch_out1, ch_out2, kernel_size=k2,stride=s2,padding=1,bias=True),
            nn.LeakyReLU(inplace=True)
        )

    def forward(self,x):
        """
        Forward pass through the convolutional block.
        """
        x = self.conv(x)
        return x
    
# Define an upsampling block using transposed convolution.
class up_conv(nn.Module):
    def __init__(self,ch_in,ch_out):
        """
        Initialises an upsampling block using ConvTranspose3d (transposed convolution) for upscaling.

        Args:
        - ch_in: Input channel size.
        - ch_out: Output channel size after upsampling.
        """
        super(up_conv,self).__init__()
        self.up = nn.Sequential(
            nn.ConvTranspose3d(ch_in, ch_out,kernel_size=2,stride=2,padding=1,bias=True,output_padding=1,dilation=2),
            nn.InstanceNorm3d(ch_in),
 	        nn.LeakyReLU(inplace=True)
        )

    def forward(self,x):
        """
        Forward pass through the upsampling block.
        """
        x = self.up(x)
        return x

# Define the 3D U-Net Model Architecture.
class U_Net3d(nn.Module):
    def __init__(self,img_ch=4,output_ch=3):
        """
        Initialises the 3D U-Net model with downsampling (encoding) and upsampling (decoding) paths.

        Args:
        - img_ch: Number of input channels (4 for our 4 scan types).
        - output_ch: Number of output channels (3 for multi-class segmentation).
        """
        super(U_Net3d,self).__init__()

        nf= 32 # Number of filters, starting at 32 and doubling down the network.
        
        # Encoding/Contracting Path
        self.Maxpool = nn.MaxPool3d(kernel_size=2,stride=2).to(device='cuda:0')
        self.Conv1 = conv_block(ch_in=img_ch,ch_out1=nf*2,ch_out2=nf*2,k1=3,k2=3,s1=1,s2=1).to(device='cuda:0')
        self.Conv2 = conv_block(ch_in=nf*2,ch_out1=nf*3,ch_out2=nf*3,k1=3,k2=3,s1=2,s2=1).to(device='cuda:0')
        self.Conv3 = conv_block(ch_in=nf*3,ch_out1=nf*4,ch_out2=nf*4,k1=3,k2=3,s1=2,s2=1).to(device='cuda:0')
        self.Conv4 = conv_block(ch_in=nf*4,ch_out1=nf*6,ch_out2=nf*6,k1=3,k2=3,s1=2,s2=1).to(device='cuda:0')
        self.Conv5 = conv_block(ch_in=nf*6,ch_out1=nf*8,ch_out2=nf*8,k1=3,k2=3,s1=2,s2=1).to(device='cuda:0')
        self.Conv6 = conv_block(ch_in=nf*8,ch_out1=nf*12,ch_out2=nf*12,k1=3,k2=3,s1=2,s2=1).to(device='cuda:0')
        self.Conv7 = conv_block(ch_in=nf*12,ch_out1=nf*16,ch_out2=nf*16,k1=3,k2=3,s1=2,s2=1).to(device='cuda:0')

        # Decoding/Expanding Path
        self.Up6 = up_conv(ch_in=nf*16,ch_out=nf*12).to(device='cuda:0')
        self.Up_conv6 = conv_block(ch_in=nf*24, ch_out1=nf*12, ch_out2=nf*12,k1=3,k2=3,s1=1,s2=1).to(device='cuda:0')
        
        self.Up5 = up_conv(ch_in=nf*12,ch_out=nf*8).to(device='cuda:0')
        self.Up_conv5 = conv_block(ch_in=nf*16, ch_out1=nf*8, ch_out2=nf*8,k1=3,k2=3,s1=1,s2=1).to(device='cuda:0')

        self.Up4 = up_conv(ch_in=nf*8,ch_out=nf*6).to(device='cuda:0')
        self.Up_conv4 = conv_block(ch_in=nf*12, ch_out1=nf*6, ch_out2=nf*6,k1=3,k2=3,s1=1,s2=1).to(device='cuda:0')
        
        self.Up3 = up_conv(ch_in=nf*6,ch_out=nf*4).to(device='cuda:0')
        self.Up_conv3 = conv_block(ch_in=nf*8, ch_out1=nf*4,ch_out2=nf*4,k1=3,k2=3,s1=1,s2=1).to(device='cuda:0')
        self.Conv_1x13 = nn.Conv3d(nf*4,output_ch,kernel_size=1,stride=1,padding=0).to(device='cuda:0')
        
        self.Up2 = up_conv(ch_in=output_ch,ch_out=nf*3).to(device='cuda:0')
        self.Up_conv2 = conv_block(ch_in=nf*6 , ch_out1=nf*3,ch_out2=nf*3,k1=3,k2=3,s1=1,s2=1).to(device='cuda:0')
        self.Conv_1x12 = nn.Conv3d(nf*3,output_ch,kernel_size=1,stride=1,padding=0).to(device='cuda:0')
        
        self.Up1 = up_conv(ch_in=output_ch,ch_out=nf*2).to(device='cuda:0')
        self.Up_conv1 = conv_block(ch_in=nf*4, ch_out1=nf*2,ch_out2=nf*2,k1=3,k2=3,s1=1,s2=1).to(device='cuda:0')
        self.Conv_1x11 = nn.Conv3d(nf*2,output_ch,kernel_size=1,stride=1,padding=0).to(device='cuda:0')
        
        # Final activation (Sigmoid for multi-class segmentation)
        self.Sig = nn.Sigmoid().to(device='cuda:0')

    def forward(self,x):
        """
        Defines the forward pass for the U-Net model, consisting of downsampling (encoding)
        followed by upsampling (decoding) layers.
        """
        # Encoding/Contracting Path
        x = x.to(device='cuda:0')
        x1 = self.Conv1(x)
        x2 = self.Conv2(x1)       
        x3 = self.Conv3(x2)
        x4 = self.Conv4(x3)       
        x5 = self.Conv5(x4)       
        x6 = self.Conv6(x5)
        x7 = self.Conv7(x6)
        
	    # Decoding/Expanding Path with Concatenation
        d6 = self.Up6(x7.to(device='cuda:0'))
        d6 = torch.cat((x6.to(device='cuda:0'), d6[:, :, :x6.size(2), :x6.size(3), :x6.size(4)]), dim=1)
        d6 = self.Up_conv6(d6)

        d5 = self.Up5(d6)
        d5 = torch.cat((x5.to(device='cuda:0'), d5[:, :, :x5.size(2), :x5.size(3), :x5.size(4)]), dim=1)
        d5 = self.Up_conv5(d5)
        
        d4 = self.Up4(d5)
        d4 = torch.cat((x4.to(device='cuda:0'), d4[:, :, :x4.size(2), :x4.size(3), :x4.size(4)]), dim=1)
        d4 = self.Up_conv4(d4)

        d3 = self.Up3(d4)
        d3 = torch.cat((x3.to(device='cuda:0'), d3[:, :, :x3.size(2), :x3.size(3), :x3.size(4)]), dim=1)
        d3 = self.Up_conv3(d3)
        d3 = self.Conv_1x13(d3)
        d3 = self.Sig(d3)
        
        d2 = self.Up2(d3)
        d2 = torch.cat((x2.to(device='cuda:0'), d2[:, :, :x2.size(2), :x2.size(3), :x2.size(4)]), dim=1)
        d2 = self.Up_conv2(d2)
        d2 = self.Conv_1x12(d2)
        d2 = self.Sig(d2)
        
        d1 = self.Up1(d2)
        d1 = torch.cat((x1.to(device='cuda:0'), d1[:, :, :x1.size(2), :x1.size(3), :x1.size(4)]), dim=1)
        d1 = self.Up_conv1(d1)
        d1 = self.Conv_1x11(d1)

        # Output Layer and Activation
        d1 = self.Sig(d1)
        return d1.to(device='cuda:0')
    
    def __str__(self):
        num_params = sum(p.numel() for p in self.parameters())
        return f"UNet_3d (with {num_params:,} parameters)"