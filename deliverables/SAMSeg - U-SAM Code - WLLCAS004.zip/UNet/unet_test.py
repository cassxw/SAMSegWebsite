"""
unet_test.py

Author: WLLCAS004
Date: July 5, 2024

Description:
This script is designed to test a trained 3D U-Net model on a specified dataset (either the testing or validation set).
The evaluation includes calculating loss metrics (such as the Dice Score) and optionally visualising the segmentation results.

CLI Parameters:
    --checkpoint_path: Path to the trained U-Net model checkpoint.
    --visualise: Boolean flag to specify if predictions should be visualized and saved as plots.
    --results_dir: Directory where visualizations will be saved (required if --visualise is set).
    --validate: Boolean flag to run the script on the validation set instead of the testing set.

Testing/Validating Use Case:
$ python3 UNet/unet_test.py --checkpoint_path checkpoints/unet_epoch_100.pth.tar --visualise --results_dir UNet/unet_test_results --batch_size 1
$ python3 UNet/unet_test.py --checkpoint_path checkpoints/unet_epoch_100.pth.tar --visualise --results_dir UNet/unet_test_results --batch_size 1 --validate

Citations:
    - The Segment Anything Model (SAM).
    - BraTS Intracranial Meningioma 2023 Challenge Dataset.
    - PyTorch, NumPy, Monai libraries.
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/model_routines/validate.py
    
"""

import os
import argparse
import numpy as np

import torch

from monai.metrics import DiceMetric

from utilities.model_utils import make_dataloader, unet_compute_loss
from utilities.general_utils import unet_seg_to_one_hot_channels, unet_disjoint_to_overlapping, unet_probs_to_preds, one_hot_channels_to_three_labels, save_pred_as_nifti
from utilities.plot import plot_slices

TESTING_SET_DIR = './dataset/BraTS-MEN-Test'
VALIDATION_SET_DIR = './dataset/BraTS-MEN-Validate'

#------------------------------------------------------------------------------------------------------------------------------------
def test(checkpoint_path, eval_regions='overlapping', results_dir=None, make_visuals=False, batch_size=1, on_validation=False):
    """
    Test the U-Net model on the specified dataset (either validation or test set).

    Args:
        checkpoint_path (str): Path to the model checkpoint.
        eval_regions (str): Defines whether evaluation is on 'disjoint' or 'overlapping' regions. Defaults to 'overlapping'.
        results_dir (str): Directory where results/visualizations will be saved. Defaults to None (i.e., current directory).
        make_visuals (bool): Flag to visualize and save segmentation results. Defaults to False.
        batch_size (int): Batch size for the DataLoader. Defaults to 1.
        on_validation (bool): Flag to determine whether to use the validation dataset instead of the testing dataset.
    """

    # Set up output directories.
    if results_dir is None:
        results_dir = os.getcwd()

    if make_visuals:
        plots_dir = os.path.join(results_dir, 'plots')
        if not os.path.exists(plots_dir):
            os.makedirs(plots_dir)                  # Create the directory if it doesn't exist.
            os.system(f'chmod a+rwx {plots_dir}')   # Ensure permissions for the directory.
    
    #--------------------------------------------------------------------
    # Load the checkpoint and retrieve model, loss functions, and additional information.
    print(f"Loading model from {checkpoint_path}...")
    checkpoint = torch.load(checkpoint_path)
    
    model = checkpoint['model']
    loss_functions = checkpoint['loss_functions']
    loss_weights = checkpoint['loss_weights']
    training_regions = checkpoint['training_regions']

    epoch = checkpoint['epoch']

    # Load the model state dictionary
    model.load_state_dict(checkpoint['model_sd'])
    print('3D U-Net Model loaded.')
    #---------------------------------------------------

    # Determine which dataset to use (validation or test).
    if (on_validation):
        data_dir = VALIDATION_SET_DIR
    else:
        data_dir = TESTING_SET_DIR

    print("---------------------------------------------------")
    print(f"TRAINING SUMMARY")
    print(f"Model: {model}")
    print(f"Loss functions: {loss_functions}") 
    print(f"Loss weights: {loss_weights}")
    print(f"Training regions: {training_regions}")
    print(f"Epochs trained: {epoch}")
    print("---------------------------------------------------")
    print("TESTING SUMMARY")
    print(f"Data directory: {data_dir}")
    print(f"Trained model checkpoint path: {checkpoint_path}")
    print(f"Evaluation regions: {eval_regions}")
    print(f"Out directory: {results_dir}")
    print(f"Make plots: {make_visuals}")
    print(f"Batch size: {batch_size}")
    print("---------------------------------------------------")

    # DataLoader Setup.
    test_loader = make_dataloader(data_dir, shuffle=False, mode='train', batch_size=batch_size)

    # Hold Testing Loss values for each scan type (without Bounding Box Emulation).
    val_loss_vals = []
    val_loss_vals_t1c = []
    val_loss_vals_t1n = []
    val_loss_vals_t2f = []
    val_loss_vals_t2w = []

    # Hold Testing Loss values for each scan type (with Bounding Box Emulation).
    emu_val_loss_vals = []
    emu_val_loss_vals_t1c = []
    emu_val_loss_vals_t1n = []
    emu_val_loss_vals_t2f = []
    emu_val_loss_vals_t2w = []

    # Dice Metric Set Up, for each scan type (without Bounding Box Emulation).
    dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    dice_metric_t1c = DiceMetric(include_background=True, reduction="mean_batch")
    dice_metric_t1n = DiceMetric(include_background=True, reduction="mean_batch")
    dice_metric_t2f = DiceMetric(include_background=True, reduction="mean_batch")
    dice_metric_t2w = DiceMetric(include_background=True, reduction="mean_batch")

    # Dice Metric Set Up, for each scan type (with Bounding Box Emulation).
    emu_dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    emu_dice_metric_t1c = DiceMetric(include_background=True, reduction="mean_batch")
    emu_dice_metric_t1n = DiceMetric(include_background=True, reduction="mean_batch")
    emu_dice_metric_t2f = DiceMetric(include_background=True, reduction="mean_batch")
    emu_dice_metric_t2w = DiceMetric(include_background=True, reduction="mean_batch")

    DEVICE = torch.device("cuda:0")
    print('Testing starts.\n')

    # Testing Loop.
    with torch.no_grad():
        for sample_names, imgs, seg in test_loader:

            model.eval()

            # Move inputs to GPU.
            imgs = [img.cuda() for img in imgs] # [Bx1xHxWxD]
            seg = seg.cuda()                    # [Bx1xHxWxD]

            # Split segmentation into 3 channels.
            seg = unet_seg_to_one_hot_channels(seg) # [Bx3xHxWxD]

            # Adjust segmentation based on training region strategy (disjoint or overlapping).
            if training_regions == 'overlapping':
                seg_train = unet_disjoint_to_overlapping(seg)
                # seg_train is B3HWD - each channel is one-hot encoding of an overlapping region
            elif training_regions == 'disjoint':
                seg_train = seg
                # seg_train is B3HWD - each channel is one-hot encoding of a disjoint region

            # Predict outputs for all MRI modalities.
            x_in = torch.cat(imgs, dim=1) # Combine inputs along channel dimension.
            output = model(x_in).to(DEVICE)
            output = output.float()

            x_in = torch.cat([imgs[0], imgs[0], imgs[0], imgs[0]], dim=1)
            output_t1c = model(x_in).to(DEVICE)
            output_t1c = output_t1c.float()
            
            x_in = torch.cat([imgs[1], imgs[1], imgs[1], imgs[1]], dim=1)
            output_t1n = model(x_in).to(DEVICE)
            output_t1n = output_t1n.float()
            
            x_in = torch.cat([imgs[2], imgs[2], imgs[2], imgs[2]], dim=1)
            output_t2f = model(x_in).to(DEVICE)
            output_t2f = output_t2f.float()
            
            x_in = torch.cat([imgs[3], imgs[3], imgs[3], imgs[3]], dim=1)
            output_t2w = model(x_in).to(DEVICE)
            output_t2w = output_t2w.float()

            # Since SAM has the added advantage of the bounding box,
            # we will intentionally be zeroing out the slices of U-Net's output
            # that U-Net may have erroneously predicted which SAM would never have predicted on.
            # U-Net seems to suffer from false positives & negatives
            # i.e. Zero-out certain predictions for slices without tumors using Bounding Box Emulation.

            emu_output = output.clone()
            emu_output_t1c = output_t1c.clone()
            emu_output_t1n = output_t1n.clone()
            emu_output_t2f = output_t2f.clone()
            emu_output_t2w = output_t2w.clone()
            
            # Process each slice along the depth dimension.
            for slice_idx in range(seg_train.shape[4]):

                # Extract the 2D binary mask for the current slice, only the WT.
                seg_slice = seg_train[:, :, :, :, slice_idx]

                # Check if current slice does not contain any tumour.
                if not seg_slice.sum() > 0:

                    # Zero out the current slice in the output if no tumour is found.
                    emu_output[:, :, :, :, slice_idx] = 0
                    emu_output_t1c[:, :, :, :, slice_idx] = 0
                    emu_output_t1n[:, :, :, :, slice_idx] = 0
                    emu_output_t2f[:, :, :, :, slice_idx] = 0
                    emu_output_t2w[:, :, :, :, slice_idx] = 0

            # Compute weighted loss, summed across each training region (without Bounding Box Emulation).
            val_loss = unet_compute_loss(output, seg_train, loss_functions, loss_weights)
            val_loss_vals.append(val_loss.detach().cpu())

            val_loss_t1c = unet_compute_loss(output_t1c, seg_train, loss_functions, loss_weights)
            val_loss_vals_t1c.append(val_loss_t1c.detach().cpu())

            val_loss_t1n = unet_compute_loss(output_t1n, seg_train, loss_functions, loss_weights)
            val_loss_vals_t1n.append(val_loss_t1n.detach().cpu())

            val_loss_t2f = unet_compute_loss(output_t2f, seg_train, loss_functions, loss_weights)
            val_loss_vals_t2f.append(val_loss_t2f.detach().cpu())

            val_loss_t2w = unet_compute_loss(output_t2w, seg_train, loss_functions, loss_weights)
            val_loss_vals_t2w.append(val_loss_t2w.detach().cpu())

            # Compute weighted loss, summed across each training region (with Bounding Box Emulation).
            emu_val_loss = unet_compute_loss(emu_output, seg_train, loss_functions, loss_weights)
            emu_val_loss_vals.append(emu_val_loss.detach().cpu())

            emu_val_loss_t1c = unet_compute_loss(emu_output_t1c, seg_train, loss_functions, loss_weights)
            emu_val_loss_vals_t1c.append(emu_val_loss_t1c.detach().cpu())

            emu_val_loss_t1n = unet_compute_loss(emu_output_t1n, seg_train, loss_functions, loss_weights)
            emu_val_loss_vals_t1n.append(emu_val_loss_t1n.detach().cpu())

            emu_val_loss_t2f = unet_compute_loss(emu_output_t2f, seg_train, loss_functions, loss_weights)
            emu_val_loss_vals_t2f.append(emu_val_loss_t2f.detach().cpu())

            emu_val_loss_t2w = unet_compute_loss(emu_output_t2w, seg_train, loss_functions, loss_weights)
            emu_val_loss_vals_t2w.append(emu_val_loss_t2w.detach().cpu())

            # Convert probabilities to binary prediction (without Bounding Box Emulation).
            preds = unet_probs_to_preds(output, eval_regions)
            preds_t1c = unet_probs_to_preds(output_t1c, eval_regions)
            preds_t1n = unet_probs_to_preds(output_t1n, eval_regions)
            preds_t2f = unet_probs_to_preds(output_t2f, eval_regions)
            preds_t2w = unet_probs_to_preds(output_t2w, eval_regions)

            # Convert probabilities to binary prediction (with Bounding Box Emulation).
            emu_preds = unet_probs_to_preds(emu_output, eval_regions)
            emu_preds_t1c = unet_probs_to_preds(emu_output_t1c, eval_regions)
            emu_preds_t1n = unet_probs_to_preds(emu_output_t1n, eval_regions)
            emu_preds_t2f = unet_probs_to_preds(emu_output_t2f, eval_regions)
            emu_preds_t2w = unet_probs_to_preds(emu_output_t2w, eval_regions)

            if eval_regions == 'overlapping':
                # Convert seg and pred to 3 channels corresponding to overlapping regions
                seg_eval = unet_disjoint_to_overlapping(seg)

                # Prediction conversion (without Bounding Box Emulation)
                preds_eval = unet_disjoint_to_overlapping(preds)
                preds_eval_t1c = unet_disjoint_to_overlapping(preds_t1c)
                preds_eval_t1n = unet_disjoint_to_overlapping(preds_t1n)
                preds_eval_t2f = unet_disjoint_to_overlapping(preds_t2f)
                preds_eval_t2w = unet_disjoint_to_overlapping(preds_t2w)

                # Prediction conversion (with Bounding Box Emulation)
                emu_preds_eval = unet_disjoint_to_overlapping(emu_preds)
                emu_preds_eval_t1c = unet_disjoint_to_overlapping(emu_preds_t1c)
                emu_preds_eval_t1n = unet_disjoint_to_overlapping(emu_preds_t1n)
                emu_preds_eval_t2f = unet_disjoint_to_overlapping(emu_preds_t2f)
                emu_preds_eval_t2w = unet_disjoint_to_overlapping(emu_preds_t2w)

            elif eval_regions == 'disjoint':
                # Convert seg and pred to 3 channels corresponding to disjoint regions
                seg_eval = seg

                # Prediction conversion (without Bounding Box Emulation)
                preds_eval = preds
                preds_eval_t1c = preds_t1c
                preds_eval_t1n = preds_t1n
                preds_eval_t2f = preds_t2f
                preds_eval_t2w = preds_t2w

                # Prediction conversion (with Bounding Box Emulation)
                emu_preds_eval = emu_preds
                emu_preds_eval_t1c = emu_preds_t1c
                emu_preds_eval_t1n = emu_preds_t1n
                emu_preds_eval_t2f = emu_preds_t2f
                emu_preds_eval_t2w = emu_preds_t2w

            # seg_eval is B3HWD
            # preds_eval is B3HWD

            # Compute metrics between seg_eval and preds_eval (without Bounding Box Emulation).
            dice_metric(y_pred=preds_eval, y=seg_eval)
            dice_metric_t1c(y_pred=preds_eval_t1c, y=seg_eval)
            dice_metric_t1n(y_pred=preds_eval_t1n, y=seg_eval)
            dice_metric_t2f(y_pred=preds_eval_t2f, y=seg_eval)
            dice_metric_t2w(y_pred=preds_eval_t2w, y=seg_eval)

            # Compute metrics between seg_eval and preds_eval (with Bounding Box Emulation).
            emu_dice_metric(y_pred=emu_preds_eval, y=seg_eval)
            emu_dice_metric_t1c(y_pred=emu_preds_eval_t1c, y=seg_eval)
            emu_dice_metric_t1n(y_pred=emu_preds_eval_t1n, y=seg_eval)
            emu_dice_metric_t2f(y_pred=emu_preds_eval_t2f, y=seg_eval)
            emu_dice_metric_t2w(y_pred=emu_preds_eval_t2w, y=seg_eval)

            # Visualisation (optional)
            if make_visuals:

                # Make plots for each subject in batch.
                for i, sample_name in enumerate(sample_names):

                    batch_imgs = [img[i, 0].cpu().detach() for img in imgs]

                    seg3 = one_hot_channels_to_three_labels(seg[i].cpu().detach()) # [HxWxD]
                    pred3 = one_hot_channels_to_three_labels(emu_preds[i])         # [HxWxD]
                    pred3_t1c = one_hot_channels_to_three_labels(emu_preds_t1c[i]) # [HxWxD]
                    pred3_t1n = one_hot_channels_to_three_labels(emu_preds_t1n[i]) # [HxWxD]
                    pred3_t2f = one_hot_channels_to_three_labels(emu_preds_t2f[i]) # [HxWxD]
                    pred3_t2w = one_hot_channels_to_three_labels(emu_preds_t2w[i]) # [HxWxD]

                    # Convert seg3 and pred3 to binary arrays, only 0 and 1.
                    seg3 = (seg3 > 0).numpy().astype(np.uint8) # (H, W, D)
                    pred3 = (pred3 > 0).numpy().astype(np.uint8) # (H, W, D)
                    pred3_t1c = (pred3_t1c > 0).numpy().astype(np.uint8) # (H, W, D)
                    pred3_t1n = (pred3_t1n > 0).numpy().astype(np.uint8) # (H, W, D)
                    pred3_t2f = (pred3_t2f > 0).numpy().astype(np.uint8) # (H, W, D)
                    pred3_t2w = (pred3_t2w > 0).numpy().astype(np.uint8) # (H, W, D)

                    pred_scans = []
                    pred_scans.append(pred3_t1c)
                    pred_scans.append(pred3_t1n)
                    pred_scans.append(pred3_t2f)
                    pred_scans.append(pred3_t2w)

                    fig = plot_slices(batch_imgs, seg3, pred3, pred_scans, version=f"3D U-Net {checkpoint_path}")
                    fig.savefig(os.path.join(plots_dir, sample_name))

                    # Save pred as NIFTI
                    save_pred_as_nifti(pred3, plots_dir, data_dir, sample_name)

    # Compute and report validation loss (without Bounding Box Emulation).
    average_val_loss = np.mean(val_loss_vals)
    average_val_loss_t1c = np.mean(val_loss_vals_t1c)
    average_val_loss_t1n = np.mean(val_loss_vals_t1n)
    average_val_loss_t2f = np.mean(val_loss_vals_t2f)
    average_val_loss_t2w = np.mean(val_loss_vals_t2w)

    # Compute and report validation loss (with Bounding Box Emulation).
    emu_average_val_loss = np.mean(emu_val_loss_vals)
    emu_average_val_loss_t1c = np.mean(emu_val_loss_vals_t1c)
    emu_average_val_loss_t1n = np.mean(emu_val_loss_vals_t1n)
    emu_average_val_loss_t2f = np.mean(emu_val_loss_vals_t2f)
    emu_average_val_loss_t2w = np.mean(emu_val_loss_vals_t2w)

    print(f'\nTesting completed.')

    print(f"\nNo Bounding Box Emulation-----------------------")
    print(f'Average Overall Testing loss = {average_val_loss}')
    print(f'Average t1c Testing Loss = {average_val_loss_t1c}')
    print(f'Average t1n Testing Loss = {average_val_loss_t1n}')
    print(f'Average t2f Testing Loss = {average_val_loss_t2f}')
    print(f'Average t2w Testing Loss = {average_val_loss_t2w}')

    # Aggregate and report the Dice scores.
    dice_metric_batch = dice_metric.aggregate()
    for i in range(3):
        print(f"Overall Dice Score {i}: {dice_metric_batch[i].item()}")
    
    print()
    dice_metric_batch = dice_metric_t1c.aggregate()
    for i in range(3):
        print(f"t1c Dice Score {i}: {dice_metric_batch[i].item()}")

    print()
    dice_metric_batch = dice_metric_t1n.aggregate()
    for i in range(3):
        print(f"t1n Dice Score {i}: {dice_metric_batch[i].item()}")

    print()
    dice_metric_batch = dice_metric_t2f.aggregate()
    for i in range(3):
        print(f"t2f Dice Score {i}: {dice_metric_batch[i].item()}")

    print()
    dice_metric_batch = dice_metric_t2w.aggregate()
    for i in range(3):
        print(f"t2w Dice Score {i}: {dice_metric_batch[i].item()}")

    print(f"\nWith Bounding Box Emulation-----------------------")
    print(f'Average Overall Testing Loss = {emu_average_val_loss}')
    print(f'Average t1c Testing Loss = {emu_average_val_loss_t1c}')
    print(f'Average t1n Testing Loss = {emu_average_val_loss_t1n}')
    print(f'Average t2f Testing Loss = {emu_average_val_loss_t2f}')
    print(f'Average t2w Testing Loss = {emu_average_val_loss_t2w}')

    # Aggregate and report the Dice scores.
    dice_metric_batch = emu_dice_metric.aggregate()
    for i in range(3):
        print(f"Overall Dice Score {i}: {dice_metric_batch[i].item()}")
    
    print()
    dice_metric_batch = emu_dice_metric_t1c.aggregate()
    for i in range(3):
        print(f"t1c Dice Score {i}: {dice_metric_batch[i].item()}")

    print()
    dice_metric_batch = emu_dice_metric_t1n.aggregate()
    for i in range(3):
        print(f"t1n Dice Score {i}: {dice_metric_batch[i].item()}")

    print()
    dice_metric_batch = emu_dice_metric_t2f.aggregate()
    for i in range(3):
        print(f"t2f Dice Score {i}: {dice_metric_batch[i].item()}")

    print()
    dice_metric_batch = emu_dice_metric_t2w.aggregate()
    for i in range(3):
        print(f"t2w Dice Score {i}: {dice_metric_batch[i].item()}")
#-----------------------------------------------------------------------------------------------------------------------------

# CLI setup using argparse.
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="3D U-Net Testing Script")
    
    parser.add_argument('--checkpoint_path', required=True, help="Path to model checkpoint")
    parser.add_argument('--visualise', action='store_true', help="Flag to visualize and save predictions")
    parser.add_argument('--results_dir', help="Directory to save visualizations if --visualise is set")
    parser.add_argument('--batch_size', type=int, default=1, help="Batch size for data loading")
    parser.add_argument('--validate', action='store_true', help="Use the validation dataset instead of the test set")

    args = parser.parse_args()

    if args.visualise and not args.results_dir:
        raise ValueError("Please provide --results_dir if --visualise is set.")

    test(checkpoint_path=args.checkpoint_path, results_dir=args.results_dir, make_visuals=args.visualise, batch_size=args.batch_size, on_validation=args.validate)