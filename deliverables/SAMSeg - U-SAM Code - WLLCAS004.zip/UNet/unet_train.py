"""
unet_train.py

Author: WLLCAS004
Date: July 4, 2024

Description:
This script trains a 3D U-Net model for brain tumour segmentation using PyTorch.
It allows resuming training  from a checkpoint if available, or starting training from scratch.
The script supports saving  periodic backups, performing validation, and decaying the learning rate 
using exponential decay. The training setup,  hyperparameters, and file paths are configurable
via CLI parameters.

CLI Parameters:
    --checkpoint_path: Path to a model checkpoint to resume training (optional).
    --output_dir: Directory where checkpoints, logs, and other results are saved.
    --init_lr: Initial learning rate for the optimizer.
    --decay_rate: Decay rate for the learning rate (default: 0.995).
    --max_epoch: Total number of epochs to train the model.
    --batch_size: Size of the training batches (default: 1).
    --samples_per_epoch: Number of samples to be used in each epoch (default: 150).
    --backup_interval: Number of epochs between saving a backup checkpoint (default: 10).
    --validate: Flag to enable validation during training (default: False).
    --validation_interval: Number of epochs between validations (default: 5).

$ python3 UNet/unet_train.py    --checkpoint_path checkpoints/unet_epoch_100.pth.tar --output_dir UNet/training_results
                                --init_lr 0.00006 --decay_rate 0.995 --max_epoch 50
                                --batch_size 1 --samples_per_epoch 150 --backup_interval 10
                                --validate --validation_interval 5

Citations:
    - Segment Anything Model (SAM)
    - BraTS Intracranial Meningioma 2023 Challenge Dataset
    - PyTorch libraries
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/model_routines/train.py
"""

import os
import csv
import argparse

import torch
import torch.nn as nn
from torch import optim

from UNet.unet3d import U_Net3d
from utilities.model_utils import unet_load_or_initialise_training, make_dataloader, exp_decay_learning_rate, unet_train_one_epoch, unet_validate_one_epoch

TRAINING_SET_DIR = './dataset/BraTS-MEN-Train'
VALIDATION_SET_DIR = './dataset/BraTS-MEN-Validate'

def train(model, checkpoint_path, loss_functions, loss_weights, init_lr, max_epoch, output_dir=None, decay_rate=0.995, 
          backup_interval=10, samples_per_epoch=150, batch_size=1, with_validation=False, validation_interval=5):
    """
    Runs the training loop for the given model, periodically saving the training progress,
    and optionally performing validation.

    Args:
        model (torch.nn.Module): The PyTorch model to be trained.
        loss_functions (list): List of loss functions to be used during training.
        loss_weights (list): Weights corresponding to each loss function.
        init_lr (float): Initial learning rate for the optimizer.
        max_epoch (int): Maximum number of epochs to run.
        output_dir (str): Directory to save checkpoints and loss values.
        decay_rate (float): Factor to decay the learning rate after each epoch. Default: 0.995.
        backup_interval (int): Number of epochs between saving backup checkpoints. Default: 10.
        num_samples_per_epoch (int): Number of samples per epoch for training steps. Default: 150.
        batch_size (int): Batch size for the data loader. Default: 1.
        validate (bool): Whether to perform validation during training. Default: False.
        validation_interval (int): Number of epochs between validations. Default: 5.
    """
    
    # Set up output directories and paths.
    if output_dir is None:
        output_dir = os.getcwd()

    latest_checkpoint_path = os.path.join(output_dir, 'latest_checkpoint.pth.tar')
    training_loss_path = os.path.join(output_dir, 'training_loss_report.csv')

    validation_loss_path = os.path.join(output_dir, 'validation_loss_report.csv') if with_validation else None
    best_vloss_checkpoint_path = os.path.join(output_dir, 'best_vloss_checkpoint.pth.tar') if with_validation else None
    best_dice_checkpoint_path = os.path.join(output_dir, 'best_dice_checkpoint.pth.tar') if with_validation else None

    backup_checkpoints_dir = os.path.join(output_dir, 'backup_checkpoints')

    # Create backup directory if it doesn't exist.
    if not os.path.exists(backup_checkpoints_dir):
        os.makedirs(backup_checkpoints_dir)
        os.system(f'chmod a+rwx {backup_checkpoints_dir}')

    print("---------------------------------------------------")
    print(f"TRAINING SUMMARY")
    print(f"Training data directory: {TRAINING_SET_DIR}")
    print(f"Model: {model}")
    print(f"Loss functions: {loss_functions}") 
    print(f"Loss weights: {loss_weights}")
    print(f"Initial learning rate: {init_lr}")
    print(f"Max epochs: {max_epoch}")
    print(f"Out directory: {output_dir}")
    print(f"Decay rate: {decay_rate}")
    print(f"Backup interval: {backup_interval}")
    print(f"Samples Per Epoch: {samples_per_epoch}")
    print(f"Batch size: {batch_size}")
    print(f"Validation: {with_validation}")
    if with_validation:
        print(f"Validation Interval: {validation_interval}")
    print("---------------------------------------------------")

    # Initialise optimiser (Adam).
    optimiser = optim.Adam(model.parameters(), lr=init_lr, weight_decay=0, amsgrad=True)

    # Load model and optimiser state if a checkpoint exists, else start from scratch.
    if with_validation:
        epoch_start, best_vloss, best_dice = unet_load_or_initialise_training(model, optimiser, checkpoint_path, train_with_val=True)
        print(f"Best Validation Loss:\t{best_vloss}")
        print(f"Best Dice:\t{best_dice}")
    else:
        epoch_start = unet_load_or_initialise_training(model, optimiser, checkpoint_path, train_with_val=False)

    # Create the training data loader.
    train_loader = make_dataloader(TRAINING_SET_DIR, shuffle=True, mode='train', batch_size=batch_size)
    val_loader = make_dataloader(VALIDATION_SET_DIR, shuffle=False, mode='train', batch_size=batch_size) if with_validation else None

    print('Training starts.')
    for epoch in range(epoch_start, max_epoch+1):
        print(f'Starting epoch {epoch}...')

        # Apply learning rate decay.
        exp_decay_learning_rate(optimiser, epoch, init_lr, decay_rate)

        # Train for one epoch and compute the average testing loss.
        average_epoch_loss = unet_train_one_epoch(model, optimiser, train_loader, loss_functions, loss_weights, "overlapping", samples_per_epoch)
        
        # Save and report training loss to CSV.
        save_loss(training_loss_path, epoch, average_epoch_loss)
        print(f'Epoch {epoch} completed. Average loss = {average_epoch_loss}.')

        update_vloss = False
        update_dice = False

        # Perform validation if the flag is set and time to validate.
        if with_validation and epoch % validation_interval == 0:
            average_val_loss, mean_validation_dice = unet_validate_one_epoch(model, val_loader, loss_functions, loss_weights)
            save_loss(validation_loss_path, epoch, average_val_loss, mode='validation')
            print(f'Epoch {epoch} validation completed. Average validation loss = {average_val_loss}.')

            if average_val_loss < best_vloss:
                best_vloss = average_val_loss
                update_vloss = True

            if mean_validation_dice > best_dice:
                best_dice = mean_validation_dice
                update_dice = True

        # Save model checkpoint.
        print('Saving model checkpoint...')
        checkpoint = {
            'epoch': epoch,
            'model_sd': model.state_dict(),
            'optim_sd': optimiser.state_dict(),
            'model': model,
            'loss_functions': loss_functions,
            'loss_weights': loss_weights,
            'init_lr': init_lr,
            'training_regions': "overlapping",
            'decay_rate': decay_rate,
            'vloss': best_vloss,
            'dice': best_dice
        }
        torch.save(checkpoint, latest_checkpoint_path)
        print('Checkpoint saved successfully.')

        if update_vloss:
            print('New best Validation Loss!')
            torch.save(checkpoint, best_vloss_checkpoint_path)
        if update_dice:
            print('New best Validation Dice Score!')
            torch.save(checkpoint, best_dice_checkpoint_path)

        # Save backup every backup_interval epochs.
        if epoch % backup_interval == 0:
            torch.save(checkpoint, os.path.join(backup_checkpoints_dir, f'epoch_{epoch}.pth.tar'))
            print(f"Backup checkpoint saved at epoch {epoch}.")

def save_loss(csv_path, epoch, loss, mode='training'):
    """
    Appends the loss for the current epoch to a CSV file.

    Args:
        csv_path (str): Path to the CSV file.
        epoch (int): Current epoch number.
        loss (float): Loss for the epoch.
        mode (str): 'training' or 'validation' to indicate the mode. Default: 'training'.
    """
    with open(csv_path, mode='a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        if epoch == 1:
            writer.writerow(['Epoch', f'{mode.capitalize()} Loss'])
        writer.writerow([epoch, loss])

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Train SAM Brain Tumour Segmentation Model with PyTorch.")

    parser.add_argument('--checkpoint_path', type=str, required=True, help='Path to checkpoint for resuming training (optional).')
    parser.add_argument('--output_dir', type=str, default=None, help='Output directory for saving checkpoints, logs, etc.')
    parser.add_argument('--init_lr', type=float, default=0.00006, help='Initial learning rate for training.')
    parser.add_argument('--decay_rate', type=float, default=0.995, help='Decay rate for learning rate.')
    parser.add_argument('--max_epoch', type=int, default=50, help='Maximum number of epochs for training.')
    parser.add_argument('--batch_size', type=int, default=1, help='Batch size for training.')
    parser.add_argument('--samples_per_epoch', type=int, default=150, help='Number of samples per epoch.')
    parser.add_argument('--backup_interval', type=int, default=10, help='Number of epochs between backup checkpoints.')
    parser.add_argument('--validate', action='store_true', default=False, help='Enable validation during training.')
    parser.add_argument('--validation_interval', type=int, default=5, help='Number of epochs between validation checks.')

    args = parser.parse_args()

    # Load model and set device.
    model = U_Net3d()
    model.to(torch.device('cuda:0' if torch.cuda.is_available() else 'cpu'))

    # Loss functions and weights.
    loss_functions = [nn.MSELoss(), nn.CrossEntropyLoss()]
    loss_weights = [0.4, 0.7]

    # Start training.
    train(model, args.checkpoint_path, loss_functions, loss_weights, init_lr=args.init_lr, max_epoch=args.max_epoch, 
          output_dir=args.output_dir, decay_rate=args.decay_rate, backup_interval=args.backup_interval, 
          batch_size=args.batch_size, samples_per_epoch=args.samples_per_epoch, 
          with_validation=args.validate, validation_interval=args.validation_interval)