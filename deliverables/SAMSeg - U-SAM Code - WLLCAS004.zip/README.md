# SAMSeg - Project Code Submission - WLLCAS004

## U-SAM
Welcome to the SAMSeg U-SAM project!

This project includes various components for training, testing, and tuning the SAM (Segment Anything Model)
and U-Net models, as well as their combination.

This README provides instructions on setting up the environment, understanding the project structure,
and using the various scripts for training, tuning, and testing different models.

**Due to memory requirements for Vula submission, our pre-trained weights for our models and raw dataset simply could not be included in this submission.**
*Unfortunately, we found the programmatic download of the raw data from Synapse to be unreliable.*
*Even with smaller subsets of the dataset (e.g. just including the Testing Set for paper reproducibility), Vula still lost connection during upload.*
*Therefore, as a solution, the pre-trained weights and raw dataset (with out specific training/test split) will be found in this folder:*
- https://uctcloud-my.sharepoint.com/:f:/g/personal/wllcas004_myuct_ac_za/EiXGWca_UN5Ir3-_Ow00CzwB6KY-U-BPaY7yD9rkhG8ZIw?e=G2CQ9U
*If this is not available, the raw dataset and weights can be provided upon request.*
*However, this means that this project is not runnable as is, and the folders within the above shared folder need to be downloaded and copied across to the root project directory.*
*We hope that this is kindly understood!*

## Project Directory Structure
├── U-SAM/                              # Contains scripts for running and evaluating the U-SAM.
│   ├── U1-SAM2.py                        > Script for running the U1-SAM2.
│   └── U-SAM-Combo.py                    > Script for running the U-SAM combination.
├── U-Net/                              # Contains scripts related to the U-Net model.
│   ├── unet_test.py                      > Script for testing the U-Net model.
│   ├── unet_train.py                     > Script for training the U-Net model.
│   └── unet3d.py                         > U-Net architecture Implementation for 3D Segmentation.
├── SAM/                                # Contains scripts related to SAM.
│   ├── sam_test.py                       > Script for testing the SAM.
│   ├── sam_train.py                      > Script for training the SAM.
│   └── sam_tuning.py                     > Script for tuning SAM hyperparameters.
├── dataset/                            # Contains directories for Training, Validation, and Test datasets.
│   ├── BraTS-MEN-Test/
│   ├── BraTS-MEN-Train/
│   └── BraTS-MEN-Validate/
├── checkpoints/                        # Contains pre-trained model checkpoints.
│   ├── peft-sam_epoch_125.pth.tar
│   ├── unet_epoch_100.pth.tar
│   └── sam_vit_b_01ec64.pth
├── requirements.txt                    # List of required Python packages for the project.
├── preprocess.py                       # Utility Functions for Pre-Processing.
├── plot.py                             # Utility Functions for Visualisations.
├── model_utils.py                      # Utility Functions for Model Operations.
├── general_utils.py                    # General Utility Functions.
└── brats_dataset.py                    # Custom Dataset Implementation for BraTS.

## Environment Setup
To set up the environment for this project, follow these steps:

1.  **Create a Virtual Environment (optional but recommended)**:
    - Using `venv`:
        `python3 -m venv samseg-env`
        `source samseg-env/bin/activate`

    - Using `conda`:
        `conda create --name samseg-env python=3.8`
        `conda activate samseg-env`

2.  **Install Required Libraries**:
    - Assuming `pip` is already installed.
      If not, install it, e.g. ```conda install pip```.
    
    - `pip install -r requirements.txt`

## Usage
If you run into issues with Python not finding the created modules, run this from the root project directory before usage:
`export PYTHONPATH=$(pwd):$PYTHONPATH`

Here are the commands to run various scripts in this project:

1.  Tune SAM's Hyperparameters:
    `python3 SAM/sam_tuning.py --checkpoint_path checkpoints/sam_vit_b_01ec64.pth --output_dir SAM/tuning_outputs --n_trials 50`

2.  Train SAM
    `python3 SAM/sam_train.py   --checkpoint_path checkpoints/peft-sam_epoch_125.pth.tar --output_dir SAM/training_outputs`
                               `--init_lr 0.00006 --decay_rate 0.995 --max_epoch 50`
                               `--batch_size 1 --samples_per_epoch 150 --backup_interval 10`
                               `--validate --validation_interval 5`

3.  Test SAM with Different Configurations:
    - Vanilla SAM Test:
        `python3 SAM/sam_test.py --vanilla --visualise --results_dir SAM/vanilla_test_results --batch_size 1`
    - PEFT-SAM Test:
        `python3 SAM/sam_test.py --peft_path checkpoints/peft-sam_epoch_125.pth.tar --visualise --results_dir SAM/peft_test_results --batch_size 1`

4.  Train U-Net
    `python3 UNet/unet_train.py  --checkpoint_path checkpoints/unet_epoch_100.pth.tar --output_dir UNet/training_outputs`
                                `--init_lr 0.00006 --decay_rate 0.995 --max_epoch 50`
                                `--batch_size 1 --samples_per_epoch 150 --backup_interval 10`
                                `--validate --validation_interval 5`

5.  Test U-Net
    `python3 UNet/unet_test.py --checkpoint_path checkpoints/unet_epoch_100.pth.tar --visualise --results_dir UNet/unet_test_results --batch_size 1`

6.  Run U-SAM-Combo
    `python3 U-SAM/U-SAM-Combo.py    --unet_checkpoint checkpoints/unet_epoch_100.pth.tar --sam_checkpoint checkpoints/peft-sam_epoch_125.pth.tar`
                                    `--visualise --output_dir U-SAM/u-sam-combo-results`
                                    `--bbox_emulation`

7.  Run U1-SAM2
    `python3 U-SAM/U1-SAM2.py    --unet_checkpoint checkpoints/unet_epoch_100.pth.tar --sam_checkpoint checkpoints/peft-sam_epoch_125.pth.tar`
                                `--visualise --output_dir U-SAM/u1-sam2-results`
                                `--bbox_emulation`

## Notes
- Ensure that the paths provided to the scripts are correct.
- For GPU support, make sure you have CUDA installed and properly configured.
- This code has been tested on A100 Core GPU on UCT's HPC.
- All citations can be found in our paper and within the code, with special thanks to the Kurtlab BraTS 2023 submission for their adaptable project setup.