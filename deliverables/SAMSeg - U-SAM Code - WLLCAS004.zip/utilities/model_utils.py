"""
model_utils.py

Author: WLLCAS004
Date: July 4, 2024

Description:
This module contains utility functions to facilitate model training, particularly for segmentation models 
based on the Segment Anything Model (SAM) architecture. The utilities cover various stages of the training 
pipeline, including data loading, loss computation, learning rate adjustment, checkpoint management, and 
model initialisation. The module is specifically tailored for the BraTS Intracranial Meningioma 2023 Challenge 
dataset but can be adapted for other segmentation tasks. The code is designed to handle complex 3D medical 
image segmentation scenarios, optimise training speed, and manage memory efficiently on GPUs.

Key features:
- Loading and shuffling datasets using `DataLoader`.
- Custom loss computation supporting multiple loss functions with weighted contributions.
- Exponential decay for learning rate scheduling.
- Efficient model training with on-the-fly memory management, especially for large 3D images.

Citations:
    - Segment Anything Model (SAM)
    - BraTS Intracranial Meningioma 2023 Challenge Dataset
    - PyTorch, NumPy libraries
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/utils/model_utils.py
"""

import os
import numpy as np

import torch
from torch.utils.data import DataLoader
from torch.nn.functional import threshold, normalize

from monai.metrics import DiceMetric

from utilities.brats_dataset import BratsDataset
from utilities.general_utils import probs_to_preds, unet_probs_to_preds, seg_to_binary, generate_bbox, unet_seg_to_one_hot_channels, unet_disjoint_to_overlapping

from segment_anything import SamPredictor
from segment_anything.utils.transforms import ResizeLongestSide

VANILLA_PATH = 'checkpoints/sam_vit_b_01ec64.pth'

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def make_dataloader(data_dir, shuffle, mode, batch_size=1):
    """
    Creates a DataLoader instance for loading the given dataset.

    Args:
        data_dir (str): Path to the dataset directory.
        shuffle (bool): Whether to shuffle the data.
        mode (str): Mode for the dataset ('train', 'test').
        batch_size (int, optional): Number of samples per batch. Defaults to 1.

    Returns:
        DataLoader: DataLoader instance configured for the dataset.
    """
    dataset = BratsDataset(data_dir, mode=mode)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=1, pin_memory=True)
    return dataloader

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def exp_decay_learning_rate(optimiser, epoch, init_lr, decay_rate):
    """
    Adjusts the learning rate using exponential decay, helping reduce the learning rate as training progresses.

    Args:
        optimiser (torch.optim.Optimizer): Optimiser whose learning rate will be modified.
        epoch (int): Current training epoch.
        init_lr (float): Initial learning rate value.
        decay_rate (float): Decay factor for each epoch.
    """
    lr = init_lr * (decay_rate ** (epoch-1))
    for param_group in optimiser.param_groups:
        param_group['lr'] = lr

def compute_loss(output, seg, loss_functs, loss_weights):
    """
    Calculate the weighted loss using a list of loss functions and their respective weights.

    Args:
        output (torch.Tensor): Model output (predictions).
        seg (torch.Tensor): Ground truth segmentation labels.
        loss_functs (list): List of loss functions to apply.
        loss_weights (list): Weights for each loss function.

    Returns:
        torch.Tensor: The computed weighted loss.
    """
    loss = 0.0

    for n, loss_function in enumerate(loss_functs):      
        temp = loss_function(output.cuda(), seg.cuda()) # Move data to GPU for loss computation.
        loss += temp * loss_weights[n] # Weight each loss component.

    return loss

def unet_compute_loss(output, seg, loss_functs, loss_weights):
    """
    Computes the weighted loss between the model output and ground truth for a 3D U-Net model.

    Args:
        output (torch.Tensor): Model output predictions with shape [B, C, H, W, D].
        seg (torch.Tensor): Ground truth segmentation labels with shape [B, C, H, W, D].
        loss_functs (list): List of loss functions to apply, where each loss function is used to compute a specific type of loss.
        loss_weights (list): List of weights corresponding to each loss function to apply.

    Returns:
        torch.Tensor: The computed weighted loss, which is the sum of individual losses weighted by their respective weights.
    """
    
    # Initialize total loss to zero.
    loss = 0.

    # Iterate over each loss function and its corresponding weight.
    for n, loss_function in enumerate(loss_functs):

        # Initialize temporary loss for the current loss function.
        temp = 0

        # Loop over each channel (assuming 3 channels in the segmentation output).
        for i in range(3):
            # Compute the loss for the current channel and accumulate.
            # Move tensors to GPU for computation.
            temp += loss_function(output[:, i:i+1].cuda(), seg[:, i:i+1].cuda())

        # Weight the accumulated loss by the corresponding weight and add to the total loss.
        loss += temp * loss_weights[n]

    return loss

def train_one_epoch(model, optimiser, train_loader, loss_functions, loss_weights, num_samples_per_epoch):
    """
    Performs one training loop of model according to given optimiser, loss functions and associated weights.

    Args:
        model (torch.nn.Module): The PyTorch model to be trained.
        optimiser (torch.optim.Optimizer): The optimiser used for training.
        train_loader (DataLoader): DataLoader for the training data.
        loss_functions (list): List of loss functions used during training.
        loss_weights (list): Weights for the loss functions.
        num_samples_per_epoch (int): Number of samples to process per epoch.

    Returns:
        The average training loss over the epoch.
    """
    DEVICE = torch.device('cuda:0') # Ensure training is on the GPU.
    losses_over_epoch = [] # Track training losses to compute average at the end.

    count = 1
    # Iterate over batches from the DataLoader
    for _, imgs, seg in train_loader:
        
        # Stop if sample limit reached.
        if (count  == num_samples_per_epoch+1):
            break

        # Clear cache at the start of each iteration.
        torch.cuda.empty_cache()

        # Set model to training mode.
        model.train()

        # EVERY SECOND TUMOUR SLICE
        #---------------------------------------------------------------------------------------------
        # Move input data (images and segmentations) to GPU.
        # non_blocking=True to speed up transfers.
        imgs = [img.cuda(non_blocking=True) for img in imgs] # [B,C,H,W,D]
        seg = seg.cuda(non_blocking=True)                    # [B,C,H,W,D]

        # Convert segmentation to binary mask.
        seg = seg_to_binary(seg)
        # seg is now B1HWD - each voxel is either 0 (Not Tumour) or 1 (Tumour).

        # Convert grayscale images to RGB.
        imgs = [torch.cat([img, img, img], dim=1) for img in imgs] # img is B3HWD
        # = torch.Size([1, 3, 138, 202, 138])

        # Initialise output tensor for combined predictions.
        combined_output = torch.zeros_like(seg, device=DEVICE) # [B,C,H,W,D]
        
        # Determine slice areas.
        slice_areas = []  # List to hold (slice_idx, area) tuples.
        for z in range(seg.size(4)):
            slice_areas.append((z, seg[0, 0, :, :, z].sum().item()))

        # Filter out slices with 0 area.
        slice_areas = [slice_info for slice_info in slice_areas if slice_info[1] > 0]

        # Sort slices by tumour area in descending order.
        slice_areas.sort(key=lambda x: x[1], reverse=True)
            
        # Select every second slice.
        slices = slice_areas[::2]

        # Zero out slices not in the selected list.
        for z in range(seg.size(4)):
            if z not in [slice_idx for slice_idx, _ in slices]:
                seg[:, :, :, :, z] = 0

        # Process each selected slice.
        for (slice_idx, _) in slices:

            # Extract the 2D binary mask for the current slice.
            seg_slice = seg[:, :, :, :, slice_idx] # [B,C,H,W]

            # Only process slices that contain tumours.
            if seg_slice.sum() > 0: 

                # Initialise the combined output mask to be the same shape as seg_slice.
                combined_output_slice = torch.zeros_like(seg_slice, device=DEVICE) # [B,C,H,W]

                # Generate the bounding box for the tumour region in the current slice.
                bbox_coord = np.array(generate_bbox(seg_slice[0, 0, :, :].cpu().numpy(), margin=0))

                # Process each scan type.
                for scan_type in range(4):
                    
                    img_slice = imgs[scan_type][0, :, :, :, slice_idx].permute(1, 2, 0).cpu().numpy()
                    original_image_size = tuple(img_slice.shape[:2]) # (H,W,C) = (138,202,3)

                    # Ensure img_slice is in uint8 format.
                    if img_slice.dtype != np.uint8:
                        img_slice = (img_slice * 255).astype(np.uint8)

                    # Resize image and apply transformations for SAM model
                    #------------------------------------------------------------------------------------------------------------------
                    # Resize the longest side to 1024, preserving aspect ratio.
                    transform = ResizeLongestSide(model.image_encoder.img_size)
                    img_slice = transform.apply_image(img_slice) # (H,W,C) = (700,1024,3)

                    # Convert to tensor, with batch dimension and permute.
                    img_slice = torch.as_tensor(img_slice, device=DEVICE).unsqueeze(0).permute(0, 3, 1, 2) # [B,C,H,W] = [B,3,700,1024]

                    # SAM Preprocessing of the image: Normalise pixel values and pad to a square input.
                    img_slice = model.preprocess(img_slice).to(DEVICE) # [B,C,H,W] = [B,3,1024,1024]
                    #------------------------------------------------------------------------------------------------------------------

                    input_size = tuple(img_slice.shape[-2:])

                    # Generate embeddings.
                    with torch.no_grad():
                        image_embedding = model.image_encoder(img_slice)

                        # apply_boxes expects prompt_box to be a numpy array shape Bx4.
                        box = transform.apply_boxes(bbox_coord, original_image_size)
                        box_torch = torch.as_tensor(box, dtype=torch.float, device=DEVICE)[None, :]

                        sparse_embeddings, dense_embeddings = model.prompt_encoder(
                            points=None,
                            boxes=box_torch,
                            masks=None,
                        )

                    # Generate low-resolution mask predictions for the tumour region.
                    low_res_masks, _ = model.mask_decoder(
                        image_embeddings=image_embedding,
                        image_pe=model.prompt_encoder.get_dense_pe(),
                        sparse_prompt_embeddings=sparse_embeddings,
                        dense_prompt_embeddings=dense_embeddings,
                        multimask_output=False,
                    )
                    # low_res_masks has shape: [B,C,H,W] = [B,1,256,256]

                    # Post-process the masks to match the original slice size.
                    upscaled_masks = model.postprocess_masks(low_res_masks, input_size, original_image_size) # [B,C,H,W] = [B,1,138,202]

                    # Normalise and apply a threshold to the predicted mask.
                    slice_output = normalize(threshold(upscaled_masks, 0.0, 0)).to(DEVICE)
                    slice_output.requires_grad_(True) # [B,C,H,W] = [B,1,138,202]

                    # Combine the current slice output with the combined mask using a union operation.
                    combined_output_slice = torch.max(combined_output_slice, slice_output) # = [B,C,H,W] = [B,1,138,202]

                    # Delete tensors to clear memory.
                    del img_slice, box_torch, image_embedding, sparse_embeddings, dense_embeddings, low_res_masks, upscaled_masks, slice_output
                    torch.cuda.empty_cache()
                
                # Place the combined output back into the full 3D tensor at the correct slice.
                combined_output[:, :, :, :, slice_idx] = combined_output_slice

                # Delete tensors to clear memory.
                del combined_output_slice
                torch.cuda.empty_cache()

            # Delete tensors to clear memory.
            del seg_slice
            torch.cuda.empty_cache()

        # Ensure combined_output and seg are the same shape and device.
        assert combined_output.shape == seg.shape, f"Shape mismatch: {combined_output.shape} vs {seg.shape}"
        combined_output = combined_output.to(seg.device)
        seg = seg.to(DEVICE)

        # Compute weighted loss.
        loss = compute_loss(combined_output, seg, loss_functions, loss_weights)
        #---------------------------------------------------------------------------------------------

        optimiser.zero_grad() # Reset the gradients for the optimiser.
        loss.backward() # Backpropagate the loss.
        optimiser.step() # Perform a gradient descent step.

        losses_over_epoch.append(loss.detach().cpu())

        # Delete output to free up memory.
        del imgs, seg, combined_output
        torch.cuda.empty_cache()

        count += 1

    # Return the average training loss over the epoch.
    average_epoch_loss = np.mean(losses_over_epoch)
    return average_epoch_loss

def unet_train_one_epoch(model, optimiser, train_loader, loss_functions, loss_weights, training_regions, num_samples_per_epoch):
    """
    Performs one training loop of model according to given optimiser, loss functions and associated weights.

    Args:
        model: The PyTorch model to be trained.
        optimiser: The optimizer used for training.
        train_loader: The dataloader for training data.
        loss_functions: List of loss functions.
        loss_weights: List of associated weightings for each loss function.
        training_regions: String specifying whether 'disjoint' or 'overlapping' regions will be used for training.

    Returns:
        The average training loss over the epoch.
    """
    losses_over_epoch = []

    count = 1
    for _, imgs, seg in train_loader:
        if (count == num_samples_per_epoch+1):
            break
        
        model.train()

        # Move data to GPU.
        imgs = [img.cuda() for img in imgs] # img is B1HWD
        seg = seg.cuda()

        # Split segmentation into 3 channels.
        seg = unet_seg_to_one_hot_channels(seg) # [Bx3xHxWxD]

        # Adjust segmentation based on training region strategy (disjoint or overlapping).
        if training_regions == 'overlapping':
            seg = unet_disjoint_to_overlapping(seg)
            # seg_train is B3HWD - each channel is one-hot encoding of an overlapping region

        # Predict outputs for all MRI modalities.
        x_in = torch.cat(imgs, dim=1) # Combine inputs along channel dimension.
        output = model(x_in)
        output = output.float()

        # Compute weighted loss, summed across each region.
        loss = unet_compute_loss(output, seg, loss_functions, loss_weights)

        # Perform optimisation step.
        optimiser.zero_grad()
        loss.backward()
        optimiser.step()

        # Store loss value for this batch.
        losses_over_epoch.append(loss.detach().cpu())

        count += 1

    # Compute loss from the epoch.
    average_epoch_loss = np.mean(losses_over_epoch)
    return average_epoch_loss

def validate_one_epoch(model, val_loader, loss_functions, loss_weights):
    """
    Perform validation for one epoch.

    Args:
        model: The segmentation model being validated.
        val_loader: Dataloader providing the validation data.
        loss_functions: List of loss functions to compute validation loss.
        loss_weights: List of corresponding weights for each loss function.

    Returns:
        average_val_loss: The average loss computed across the validation set.
        mean_dice: The mean Dice score computed for the entire validation set.
    """
    DEVICE = torch.device('cuda:0') # Ensure validation is on the GPU.
    print('Starting validation loop...')

    val_loss_vals = [] # List to store loss values for each batch during validation.
    dice_metric = DiceMetric(include_background=True, reduction="mean_batch") # Dice score for segmentation evaluation.

    predictor = SamPredictor(model) # Predictor instance for running segmentation predictions using SAM model.

    # Disable gradient computation for validation.
    with torch.no_grad():
        for _, imgs, seg in val_loader: # Loop over validation batches.

            model.eval() # Set model to evaluation mode to disable dropout, batch norm, etc.

            # Move images and segmentation labels to the GPU.
            imgs = [img.cuda() for img in imgs] # [Bx1xHxWxD]
            seg = seg.cuda() # [Bx1xHxWxD]

            # Convert segmentation labels to binary (0: Not Tumour, 1: Tumour).
            seg = seg_to_binary(seg) # [Bx3xHxWxD]

            # Convert each image to RGB by duplicating the single channel three times.  
            imgs = [torch.cat([img, img, img], dim=1) for img in imgs]

            # Initialise the output tensor to store predictions, same shape as seg.
            output = torch.zeros_like(seg).to(DEVICE)

            # Iterate over each slice along the depth dimension.
            for slice_idx in range(seg.shape[4]):

                # Extract the 2D binary mask for the current slice.
                seg_slice = seg[:, :, :, :, slice_idx]

                # Process only slices that contain tumour pixels.
                if seg_slice.sum() > 0:

                    # Initialize a tensor to store combined predictions for the current slice.
                    combined_output_slice = torch.zeros_like(seg_slice).to(DEVICE) # [Bx1xHxW]

                    # Generate a bounding box for the current slice to focus predictions.
                    bbox_coord = np.array(generate_bbox(seg_slice[0, 0, :, :].cpu().numpy(), margin=0))

                    # Process each scan type.
                    for scan_type in range(4):
                        
                        # Extract and prepare the image slice for the current scan type.
                        img_slice = imgs[scan_type][0, :, :, :, slice_idx].permute(1, 2, 0).cpu().numpy() # (H,W,C)

                        # Set the current image in the SAM predictor.
                        predictor.set_image(img_slice, "RGB")
                        
                        # Predict the mask for the slice using the bounding box.
                        slice_output, _, _ = predictor.predict(
                            box=bbox_coord,
                            multimask_output=False,
                        )
                        # slice_output shape is: (C,H,W)

                        # Convert the prediction to a tensor and move it to the GPU.
                        slice_output = torch.tensor(slice_output, device=DEVICE).unsqueeze(0)

                        # Combine the prediction with the current combined mask using a union operation.
                        combined_output_slice = torch.max(combined_output_slice, slice_output)
                        
                    # Store the combined mask into the output tensor at the correct slice position.
                    output[:, :, :, :, slice_idx] = combined_output_slice

            # output shape is:  # [Bx1xHxWxD]
            # seg shape is:     # [Bx1xHxWxD]

            # Compute weighted loss.
            val_loss = compute_loss(output, seg, loss_functions, loss_weights)
            val_loss_vals.append(val_loss.detach().cpu())

            # Convert the predicted probabilities to discrete predictions.
            preds = probs_to_preds(output)

            # Update the Dice metric for the current batch.
            dice_metric(y_pred=preds, y=seg)

    # Compute the average validation loss across all batches.
    average_val_loss = np.mean(val_loss_vals)
    print(f'Validation completed. Average validation loss = {average_val_loss}')

    # Aggregate and compute the final Dice score for the validation set.
    mean_dice = dice_metric.aggregate().item()
    print(f'Validation Dice Score = {mean_dice}')

    return average_val_loss, mean_dice

def unet_validate_one_epoch(model, val_loader, loss_functions, loss_weights):
    """
    Perform validation for one epoch for a U-Net model on a validation dataset.

    Args:
        model: The U-Net segmentation model.
        val_loader: Dataloader providing the validation data.
        loss_functions: List of loss functions for computing validation loss.
        loss_weights: List of corresponding weights for each loss function.

    Returns:
        average_val_loss: The average loss computed across the validation set.
        mean_dice: The mean Dice score computed across the validation set.
    """

    print('Starting validation loop...')

    val_loss_vals = [] # List to store loss values for each batch.

    # Initialise Dice metric for evaluation.
    dice_metric = DiceMetric(include_background=True, reduction="mean_batch")

    # Disable gradients for validation.
    with torch.no_grad():
        for _, imgs, seg in val_loader:
            model.eval()

            # Move inputs to GPU.
            imgs = [img.cuda() for img in imgs] # [Bx1xHxWxD]
            seg = seg.cuda()                    # [Bx1xHxWxD]

            # Split segmentation into 3 channels.
            seg = unet_seg_to_one_hot_channels(seg) # [Bx3xHxWxD]

            seg_train = unet_disjoint_to_overlapping(seg)
            # seg_train is B3HWD - each channel is one-hot encoding of an overlapping region.

            # Predict outputs for all MRI modalities.
            x_in = torch.cat(imgs, dim=1) # Combine inputs along channel dimension.
            output = model(x_in)
            output = output.float()

            # Compute weighted loss, summed across each training region.
            val_loss = unet_compute_loss(output, seg_train, loss_functions, loss_weights)
            val_loss_vals.append(val_loss.detach().cpu())

            # Convert probabilities to binary prediction.
            preds = unet_probs_to_preds(output, "overlapping")

            # Prediction conversion.
            seg_eval = unet_disjoint_to_overlapping(seg)
            preds_eval = unet_disjoint_to_overlapping(preds)

            # seg_eval is B3HWD.
            # preds_eval is B3HWD.

            # Compute metrics between seg_eval and preds_eval.
            dice_metric(y_pred = preds_eval, y = seg_eval)

    # Compute and report validation loss.
    average_val_loss = np.mean(val_loss_vals)
    print(f'Validation completed. Average validation loss = {average_val_loss}')

    # Aggregate and report the Dice scores.
    dice_metric_batch = dice_metric.aggregate()
    eval_region_dice_scores = []
    for i in range(3):
        eval_region_dice_scores.append(dice_metric_batch[i].item())
        print(f"Dice {i}: {dice_metric_batch[i].item()}")
    mean_dice = np.mean(eval_region_dice_scores[0]) #Only work with WT

    return average_val_loss, mean_dice

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def initialise_from_vanilla(model):
    """
    Initialises the model using pre-trained weights from SAM.

    This function loads a pre-trained state dictionary from the SAM model and applies it 
    to the provided model. This is useful for transfer learning, allowing the model to 
    leverage previously learned features from SAM.

    Args:
        model: The PyTorch model that will be initialised with the pre-trained weights.
        vanilla_path: The path to the file containing SAM's pre-trained weights.

    Returns:
        model: The model initialised with SAM's pre-trained weights.
    """
    print("Loading Vanilla SAM...")

    # Load the pre-trained state dictionary from SAM.
    pretrained_state_dict = torch.load(VANILLA_PATH)

    # Load the state dictionary into the current model architecture.
    model.load_state_dict(pretrained_state_dict)

    return model

def load_from_checkpoint(model, optimiser, checkpoint_path, train_with_val=False):
    """
    Loads the model and optimiser state from a previously saved training checkpoint.

    This function allows you to resume training from the last saved state, ensuring 
    that both the model's parameters and optimiser's state are restored correctly. If 
    validation metrics are being tracked, this function can also return the best saved 
    validation loss and Dice score.

    Args:
        model: The PyTorch model to be loaded.
        optimiser: The optimiser associated with the model.
        checkpoint_path: Path to the saved checkpoint file.
        train_with_val: Flag indicating whether to return validation metrics as well. 
                        Defaults to False.

    Returns:
        epoch_start: The epoch number to resume training from.
        If train_with_val is True, returns best_vloss (validation loss) and best_dice 
        (Dice score) along with epoch_start.
    """
    print("Training checkpoint found. Loading checkpoint...")

    # Load the checkpoint, which contains model, optimiser states, and additional metadata.
    checkpoint = torch.load(checkpoint_path)
    
    # Retrieve the epoch number from which to resume training (next epoch after saved).
    epoch_start = checkpoint['epoch'] + 1

    # Load the model and optimizer state dictionaries.
    model.load_state_dict(checkpoint['model_sd'])
    optimiser.load_state_dict(checkpoint['optim_sd'])

    print(f"Checkpoint loaded. Continuing training from epoch {epoch_start}.")

    # If validation metrics are tracked, return them along with the starting epoch.
    if train_with_val:
        best_vloss = checkpoint.get('vloss', float('inf'))
        best_dice = checkpoint.get('dice', 0)
        return epoch_start, best_vloss, best_dice
    
    # Return the starting epoch number.
    return epoch_start

def load_or_initialise_training(model, optimiser, latest_checkpoint_path, train_with_val=False):
    """
    Attempts to load a saved training checkpoint;
    if none exists, initializes the model  from Vanilla SAM's pre-trained weights.

    This function is useful for both starting a new training session with pre-trained 
    weights or resuming training from a checkpoint. If the checkpoint exists, the model 
    and optimiser states are restored, allowing the training to continue without loss 
    of progress.

    Args:
        model: The PyTorch model to be initialised or loaded.
        optimiser: The optimiser used for training the model.
        latest_checkpoint_path: Path to the latest checkpoint file, if it exists.
        train_with_val: If True, returns best saved validation metrics. Defaults to False.

    Returns:
        epoch_start: The epoch number to resume or start training from.
        If train_with_val is True, returns best_vloss and best_dice along with epoch_start.
    """
    # Check if a saved checkpoint exists; load from it if available.
    if latest_checkpoint_path == VANILLA_PATH:
        model = initialise_from_vanilla(model)
        epoch_start = 1 # Start training from epoch 1.

        # If training with validation, initialise best validation metrics.
        if train_with_val:
            best_vloss = float('inf') # Set a high initial validation loss.
            best_dice = 0 # Initialise best Dice score as 0.
            return epoch_start, best_vloss, best_dice
        
        return epoch_start
    
    elif os.path.exists(latest_checkpoint_path):
        return load_from_checkpoint(model, optimiser, latest_checkpoint_path, train_with_val)
    
    # If no checkpoint is found, initialise the model from Vanilla SAM's pre-trained weights.
    else:
        print("No checkpoint found!")
        model = initialise_from_vanilla(model)
        epoch_start = 1 # Start training from epoch 1.

        # If training with validation, initialise best validation metrics.
        if train_with_val:
            best_vloss = float('inf') # Set a high initial validation loss.
            best_dice = 0 # Initialise best Dice score as 0.
            return epoch_start, best_vloss, best_dice
        
        return epoch_start
    
def unet_load_or_initialise_training(model, optimiser, latest_checkpoint_path, train_with_val=False):
    """
    Loads a training checkpoint if it exists, or initialises training from scratch for a 3D U-Net model.

    Args:
        model: The PyTorch model to be trained.
        optimiser: The optimiser used for training.
        latest_checkpoint_path: The path to the most recent model checkpoint file.
        train_with_val: If True, the function also returns the best validation loss and Dice score from the checkpoint. Defaults to False.

    Returns:
        epoch_start: The epoch number to resume training from.
        If 'train_with_val' is True, also returns:
        - best_vloss: The best validation loss saved in the checkpoint.
        - best_dice: The best validation Dice score saved in the checkpoint.
    """

    # Check if a checkpoint exists at the given path.
    if not os.path.exists(latest_checkpoint_path):
        # If no checkpoint exists, initialize the training from scratch.
        epoch_start = 1
        if train_with_val:
            # Initialise best validation loss and Dice score.
            best_vloss = float('inf')
            best_dice = 0
            
        print('No training checkpoint found. Will start training from scratch.')

    else:
        # Load the checkpoint if it exists
        print('Checkpoint found. Loading checkpoint...')
        checkpoint = torch.load(latest_checkpoint_path)

        # Resume training from the next epoch.
        epoch_start = checkpoint['epoch'] + 1

        # Load the model and optimiser states from the checkpoint.
        model.load_state_dict(checkpoint['model_sd'])
        optimiser.load_state_dict(checkpoint['optim_sd'])

        # If validation metrics are being tracked, load best validation loss and Dice score.
        if train_with_val:
            best_vloss = checkpoint['vloss']
            best_dice = checkpoint['dice']
        print(f'Checkpoint loaded.')

    # Return starting epoch, and if applicable, best validation metrics.
    if train_with_val:
        return epoch_start, best_vloss, best_dice
    return epoch_start