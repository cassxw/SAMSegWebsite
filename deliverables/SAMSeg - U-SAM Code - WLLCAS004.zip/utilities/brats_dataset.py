"""
brats_dataset.py

Author: WLLCAS004
Date: July 4, 2024

Description:
This script implements a Dataset class for loading and preprocessing BraTS dataset images.

Citations:
    - The Segment Anything Model (SAM).
    - BraTS Intracranial Meningioma 2023 Challenge Dataset.
    - PyTorch, Nibabel, NumPy libraries.
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/datasets/brats_dataset.py
"""

import os
import numpy as np
import nibabel as nib

import torch
from torch.utils.data import Dataset

from utilities.preprocess import znorm_rescale, center_crop

class BratsDataset(Dataset):
    """
    Dataset class for loading BraTS training and test data.

    Args:
        data_dir (str): Path to the directory containing the dataset.
        mode (str): Either 'train' or 'test' to specify the dataset usage mode.
    """

    def __init__(self, data_dir, mode):
        """
        Initialise the dataset class.

        Args:
            data_dir (str): Directory containing the subject folders.
            mode (str): 'train' or 'test'. Determines if segmentation masks will be loaded.
        """
        self.data_dir = data_dir
        self.samples_list = os.listdir(data_dir) # List all samples in the directory.
        self.mode = mode # Specifies whether it's for training or testing.

    def __len__(self):
        """Returns the number of samples in the dataset."""
        return len(self.samples_list)
    
    def load_nifti(self, sample_name, suffix):        
        """
        Loads a NIfTI file for a specific subject based on the suffix.
        
        Args:
            subject_name (str): Name of the subject.
            suffix (str): Imaging modality (e.g. 't1c', 'seg').
        
        Returns:
            nifti (nib.Nifti1Image): Loaded NIfTI image.
        """
        nifti_filename = f'{sample_name}-{suffix}.nii.gz'
        nifti_path = os.path.join(self.data_dir, sample_name, nifti_filename)
        nifti = nib.load(nifti_path) # Load the NIfTI image.
        return nifti
    
    def load_subject_data(self, subject_name):
        """
        Loads the image modalities and segmentation (if in train mode) for a subject.
        
        Args:
            subject_name (str): Name of the subject.
        
        Returns:
            tuple: (list of modality images, segmentation mask) if training,
                   or (list of modality images) if testing.
        """

        # Load four imaging modalities -> t1c, t1n, t2f, t2w.
        modalities_data = []
        for suffix in ['t1c', 't1n', 't2f', 't2w']:
            modality_nifti = self.load_nifti(subject_name, suffix)
            modality_data = modality_nifti.get_fdata() # Get the voxel data.
            modalities_data.append(modality_data)

        # Load segmentation mask if in training mode.
        if self.mode == 'train':
            seg_nifti = self.load_nifti(subject_name, 'seg')
            seg_data = seg_nifti.get_fdata()
            return modalities_data, seg_data
        
        elif self.mode == 'test':
            return modalities_data
    
    def __getitem__(self, idx):
        """
        Retrieves and processes a sample by index.

        Args:
            idx (int): Index of the sample in the list.
        
        Returns:
            tuple: (subject_name, list of preprocessed images, segmentation mask) if training,
                   or (subject_name, list of preprocessed images) if testing.
        """
        sample_name = self.samples_list[idx] # Retrieve the sample's folder name.

        # Load the image data (and segmentation if in train mode).
        if self.mode == 'train':
            imgs, seg = self.load_subject_data(sample_name)
        elif self.mode == 'test':
            imgs = self.load_subject_data(sample_name)

        # Pre-Processing:
        # Z-Score Normalisation and Rescaling for each image.
        imgs = [znorm_rescale(img) for img in imgs]

        # Center-Cropping for each image.
        imgs = [center_crop(img) for img in imgs]

        # Add a channel dimension (for compatibility with SAM and PyTorch DL).
        imgs = [x[None, ...] for x in imgs]
        imgs = [np.ascontiguousarray(x, dtype=np.float32) for x in imgs]

        # Convert each image to a torch tensor.
        imgs = [torch.from_numpy(x) for x in imgs]

        # If in training mode, pre-process the segmentation.
        if self.mode == 'train':
            seg = center_crop(seg)
            seg = seg[None, ...] # Add channel dimension.
            seg = np.ascontiguousarray(seg)
            seg = torch.from_numpy(seg)

            return sample_name, imgs, seg
        
        elif self.mode == 'test':
            return sample_name, imgs