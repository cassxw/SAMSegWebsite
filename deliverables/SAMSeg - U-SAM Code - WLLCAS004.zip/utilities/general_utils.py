"""
general_utils.py

Author: WLLCAS004
Date: July 4, 2024

Description:
This module contains utility functions for handling medical image segmentation data, specifically for the BRATS 2023 dataset. 
The provided functions help in facilitating the conversion of segmentations to different formats, processing 
model outputs into predictions, handling of bounding boxes, and saving predicted segmentations as Nifti files.

Key Functions:
- Transformation of probability maps to prediction labels.
- Saving predictions in the Nifti format with consistent affine and header information.
- Binary segmentation processing and bounding box generation for multi-tumour cases using OpenCV.

Citations:
    - The Segment Anything Model (SAM).
    - BraTS Intracranial Meningioma 2023 Challenge Dataset.
    - PyTorch, Nibabel, OpenCV, NumPy libraries.
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/utils/general_utils.py
"""

import os
import cv2
import torch
import numpy as np
import nibabel as nib

from utilities.preprocess import undo_center_crop

# -------------------------------------------------------------------------------------------------------------------
# Function Definitions
# -------------------------------------------------------------------------------------------------------------------

def unet_seg_to_one_hot_channels(seg):
    """
    Converts segmentation to a one-hot encoded format with 3 distinct tumour region channels.
    
    Args:
        seg (Tensor): A tensor of shape (B, 1, H, W, D) representing voxel-wise labels.
    
    Returns:
        Tensor: A tensor of shape (B, 3, H, W, D) where each channel encodes a disjoint tumour region (label 1, 2, or 3).
    """
    B,_,H,W,D = seg.shape
    seg3 = torch.zeros((B,3,H,W,D))

    # Fill each channel with a binary mask where each voxel equals the channel's label (1, 2, or 3).
    for channel_value in [1,2,3]:
        seg3[:, channel_value-1, :, :, :] = (seg == channel_value).type(torch.float)

    return seg3

    # Disjoint Version =
    # Channel 1: (Non-Enhancing Tumour Core): Only contains label 1.
    # Channel 2: (Enhancing Tumour): Only contains label 2.
    # Channel 3: (Surrounding Non-Enhancing FLAIR Hyperintensity): Only contains label 3.

def unet_disjoint_to_overlapping(seg_disjoint):
    """
    Converts one-hot encoded disjoint tumour regions to overlapping ones,
    specifically for 3D U-Net.
    
    Args:
        seg_disjoint (Tensor): A tensor of shape (B, 3, H, W, D), where each channel is a one-hot encoding of a disjoint region.
    
    Returns:
        Tensor: A tensor of shape (B, 3, H, W, D), where channels overlap (e.g., Whole Tumor = Channel 1).
    """
    seg_overlapping = torch.zeros_like(seg_disjoint)

    # Combine disjoint labels into overlapping tumour regions.
    seg_overlapping[:,0] = seg_disjoint[:, 0] + seg_disjoint[:, 1] + seg_disjoint[:, 2] #WHOLE TUMOUR
    seg_overlapping[:,1] = seg_disjoint[:, 0] + seg_disjoint[:, 2] #TUMOUR CORE
    seg_overlapping[:,2] = seg_disjoint[:, 2] #ENHANCING TUMOUR
    return seg_overlapping

    # Overlapping Version = 
    # Channel 1 (Whole Tumor): Combination of all tumour labels (1, 2, and 3).
    # Channel 2 (Tumor Core): Combination of Non-Enhancing Tumour Core and Enhancing Tumour (labels 1 and 2).
    # Channel 3 (Enhancing Tumour): Only contains label 2.

def overlapping_probs_to_preds(output, t1=0.45, t2=0.4, t3=0.45):
    """
    Converts model output probabilities (overlapping tumour regions) to one-hot encoded disjoint regions,
    specifically for 3D U-Net.
    
    Args:
        output (Tensor): A tensor of shape (B, 3, H, W, D) representing probabilities of overlapping tumour regions.
        t1, t2, t3 (float): Thresholds for classifying each voxel as WT, TC, or ET, respectively.
    
    Returns:
        Tensor: A tensor of shape (B, 3, H, W, D) with one-hot encoded disjoint tumour regions.
    """
    output = output.cpu().detach()

    # Threshold the probabilities for each tumour region.
    c1 = output[:, 0] > t1  # Whole Tumour (WT)
    c2 = output[:, 1] > t2  # Tumour Core (TC)
    c3 = output[:, 2] > t3  # Enhancing Tumour (ET)
    
    preds = (c1 > 0).to(torch.uint8) # Initialise with WT label (label 1)
    preds[(c2 == False) * (c1 == True)] = 2 # Assign TC label (label 2)
    preds[(c3 == True) * (c1 == True)] = 3 # Assign ET label (label 3)

    # Convert predictions into one-hot encoding.
    output_plot = torch.zeros_like(output)
    output_plot[:, 0] = (preds == 1).to(torch.uint8) # NCR
    output_plot[:, 1] = (preds == 2).to(torch.uint8) # ED
    output_plot[:, 2] = (preds == 3).to(torch.uint8) # ET

    output_plot = output_plot.to(torch.uint8)
    return output_plot

def disjoint_probs_to_preds(output, t=0.5):
    """
    Converts model output probabilities (disjoint regions) to one-hot encoded disjoint regions,
    specifically for 3D U-Net.
    
    Args:
        output (Tensor): A tensor of shape (B, 3, H, W, D) representing probabilities for each disjoint region.
        t (float): Threshold for classification. Defaults to 0.5.
    
    Returns:
        Tensor: A tensor of shape (B, 3, H, W, D) with one-hot encoded disjoint tumour regions.
    """
    output = output.cpu().detach()

    c1, c2, c3 = output[:, 0], output[:, 1], output[:, 2]

    # Identify the maximum probability per voxel.
    max_label = torch.max(torch.max(c1, c2), c3)

    # Initialise the prediction array.
    preds = torch.zeros_like(output)
    preds[:, 0] = torch.where(c1 < max_label, torch.tensor(0), max_label)
    preds[:, 1] = torch.where(c2 < max_label, torch.tensor(0), max_label)
    preds[:, 2] = torch.where(c3 < max_label, torch.tensor(0), max_label)

    # Apply the threshold to produce binary values.
    output_plot = torch.zeros_like(output)
    for c in range(0, 3):
        output_plot[:, c] = torch.where(preds[:, c] > t, torch.tensor(1.), torch.tensor(0.))
        
    output_plot = output_plot.to(torch.uint8)
    return output_plot

def fetch_affine_header(sample_name, data_dir):
    """
    Fetches the affine transformation matrix and header from the t1c modality Nifti file of a given sample.
    
    Args:
        sample_name (str): The name of the subject whose data is being processed.
        data_dir (str): The parent directory containing the subject's data folder.
    
    Returns:
        Tuple: A tuple (affine, header) where 'affine' is the transformation matrix, and 'header' is the Nifti header object.
    """
    modality_nifti_filename = f'{sample_name}-t1c.nii.gz'
    modality_nifti_path = os.path.join(data_dir, sample_name, modality_nifti_filename)
    nifti = nib.load(modality_nifti_path)
    return nifti.affine, nifti.header

def one_hot_channels_to_three_labels(pred):
    """
    Converts a one-hot encoded segmentation into a single channel with disjoint region labels.
    
    Args:
        pred (ndarray): A numpy array of shape (3, H, W, D), where each channel is a one-hot encoding of disjoint regions.
    
    Returns:
        ndarray: A numpy array of shape (H, W, D) where each voxel is labeled 1, 2, or 3.
    """
    return pred[0] + pred[1]*2 + pred[2]*3

def save_pred_as_nifti(pred, save_dir, data_dir, sample_name):
    """
    Saves the predicted segmentation as a Nifti file, matching its affine and header to the sample's MRI data.
    
    Args:
        pred (Tensor): A tensor of shape (H, W, D) representing the predicted segmentation.
        save_dir (str): Directory where the Nifti file will be saved.
        data_dir (str): Parent directory of the sample's data folder.
        sample_name (str): Name of the sample whose data is being processed.
    """
    pred_for_nifti = np.squeeze(pred)
    pred_for_nifti = undo_center_crop(pred_for_nifti)
    pred_for_nifti = pred_for_nifti.astype(np.uint8)

    affine, header = fetch_affine_header(sample_name, data_dir)

    pred_nifti = nib.nifti1.Nifti1Image(pred_for_nifti, affine=affine, header=header)
    filename = f'{sample_name}.nii.gz'
    nib.nifti1.save(pred_nifti, os.path.join(save_dir, filename))

# ========================= Binary Mask and Bounding Box Utilities =========================
def probs_to_preds(output):
    """
    Converts model output probabilities into binary tumour predictions.
    
    Args:
        output (Tensor): A tensor of shape (B, 1, H, W, D) representing probabilities of a voxel belonging to a tumour.
    
    Returns:
        Tensor: A tensor of shape (B, 1, H, W, D), where voxels are either 0 (Not Tumour) or 1 (Tumour).
    """
    preds = (output > 0.5).float()
    return preds

def unet_probs_to_preds(output, training_regions):
    """Converts tensor of voxel probabilities to tensor of disjoint region labels.

    Args:
        output: Tensor of shape B3HWD. Output of model, representing probabilties each voxel belongs to a region.
        training_regions: Whether probabilities relate to overlapping or disjoint regions.

    Returns:
        Tensor of shape B3HWD, where each channel is one-hot encoding of a disjoint region.
    """
    if training_regions == 'overlapping':
        preds = overlapping_probs_to_preds(output)
    elif training_regions == 'disjoint':
        preds = disjoint_probs_to_preds(output)

    return preds

def seg_to_binary(seg):
    """
    Converts a segmentation mask into a binary mask where non-zero labels are considered tumour (1) and zeros are background (0).

    Args:
        seg (torch.Tensor): Tensor of shape (B, 1, H, W, D) where each voxel contains a label.

    Returns:
        torch.Tensor: Binary mask of shape (B, 1, H, W, D).
    """
    return (seg > 0).float()

def generate_bbox(seg_mask, margin=0):
    """
    Generates a bounding box around the tumour in a segmentation mask.

    Args:
        seg_mask (np.ndarray): 2D segmentation mask (H, W).
        margin (int, optional): Margin to add around the bounding box.

    Returns:
        tuple: Coordinates of the bounding box (x_min, y_min, x_max, y_max).
    """
    
    # Find contours.
    contours, _ = cv2.findContours(seg_mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    # Initialise the bounding box with the first contour.
    x, y, w, h = cv2.boundingRect(contours[0])
    x_min, y_min, x_max, y_max = x, y, x + w, y + h

    # Iterate over all contours to find the union of bounding boxes.
    for contour in contours[1:]:
        x, y, w, h = cv2.boundingRect(contour)
        x_min = min(x_min, x)
        y_min = min(y_min, y)
        x_max = max(x_max, x + w)
        y_max = max(y_max, y + h)

    # Adding margin.
    x_min = max(0, x_min - margin)
    y_min = max(0, y_min - margin)
    x_max = min(seg_mask.shape[1], x_max + margin)
    y_max = min(seg_mask.shape[0], y_max + margin)

    return x_min, y_min, x_max, y_max