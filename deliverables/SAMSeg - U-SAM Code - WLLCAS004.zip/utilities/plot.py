"""
plot.py

Author: WLLCAS004
Date: July 5, 2024

Description:
This script contains utility functions for tumuor segmentation visualization and analysis. The main functions 
focus on plotting MRI scans with segmentation masks, calculating the slice with the largest tumor cross-section, 
and generating overlays that show ground truth versus predicted tumor segmentation results. This assists in 
evaluating the subjective performance of models like PEFT-SAM in brain tumour segmentation tasks.

The visualisation utilities, such as bounding boxes and masks for True Positive (TP), False Positive (FP), 
and False Negative (FN), provide a clear understanding of model performance for each slice of MRI images. 

The helper functions "show_mask" and "show_box" are adapted from Encord have been customised for our use case.

Citations:
    - Segment Anything Model (SAM)
    - BraTS Intracranial Meningioma 2023 Challenge Dataset
    - NumPy, Matplotlib libraries
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/processing/plot.py
    - https://colab.research.google.com/drive/1F6uRommb3GswcRlPZWpkAQRMVNdVH7Ww?usp=sharing#scrollTo=sH6NorejpTii
"""

import numpy as np
import matplotlib.pyplot as plt

from utilities.general_utils import generate_bbox

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def max_slice(seg):
    """
    Finds the slice with the largest cross-sectional area of the tumour in a 3D segmentation.

    This function iterates over the depth dimension (z-axis) of the 3D segmentation mask
    and calculates the area of the tumor in each slice. The slice with the largest area is 
    returned, which helps to focus analysis on the most significant tumor cross-section.

    Args:
        seg (numpy array or PyTorch tensor): 3D segmentation mask with shape (H, W, D).

    Returns:
        int: Index of the slice with the largest tumor cross-sectional area.
    """
    
    # Ensure seg is a numpy array. If it's a PyTorch tensor, convert to numpy.
    if not isinstance(seg, np.ndarray):
        seg_np = seg.cpu().numpy()
        seg_np = seg_np.squeeze(0).squeeze(0) # Removing batch and channel dimensions if present.
    else:
        seg_np = seg

    # Check that the input has the correct shape (H, W, D).
    assert len(seg_np.shape) == 3, f"Expected shape (H, W, D), but got {seg_np.shape}"

    # Compute the area of the tumour in each slice along the depth dimension.
    areas = [np.sum(seg_np[:, :, i]) for i in range(seg_np.shape[2])]

    # Identify the slice with the maximum area.
    largest_slice_idx = np.argmax(areas)

    return largest_slice_idx

def plot_slices(images=None, seg=None, pred=None, pred_scans=None, version="Vanilla SAM"):
    """
    Plots MRI images and their respective ground truth and predicted segmentations.

    This function displays a set of MRI images from multiple modalities (t1c, t1n, t2f, t2w), 
    ground truth segmentation, and predicted segmentation for a particular slice. It also 
    visualises True Positive (TP), False Positive (FP), and False Negative (FN) regions to 
    compare the model's performance.

    Args:
        images (list of numpy arrays): List of MRI images from different modalities (H, W, D).
        seg (numpy array): Ground truth segmentation mask (H, W, D).
        pred (numpy array): Predicted segmentation mask (H, W, D).
        pred_scans (list of numpy arrays): List of predicted segmentation masks for each modality (optional).
        version (str): The subtitle of the resulting plot.

    Returns:
        matplotlib.figure.Figure: The figure containing the plots for MRI slices and segmentations.
    """

    # Determine the slice with the largest tumour cross-section.
    nslice = max_slice(seg)

    # Extract the corresponding ground truth and predicted segmentation for the selected slice.
    seg_slice = seg[:, :, nslice]
    pred_slice = pred[:, :, nslice]

    # Generate a bounding box around the tumour region with a margin of 3.
    bbox = np.array(generate_bbox(seg_slice, margin=3))

    # Create subplots to display the images and segmentations.
    fig, axes = plt.subplots(1, 6, figsize=(35, 5))
    fig.suptitle(f"{version} Tumour Segmentation Analysis", fontsize=20)

    # Loop through each MRI modality and display the slice with overlaid masks.
    for i, suffix in enumerate(['t1c', 't1n', 't2f', 't2w']):

        # Plot the MRI image.
        axes[i].imshow(images[i][:, :, nslice], cmap='gray')
        axes[i].set_title(f'{suffix} Scan')
        axes[i].axis('off')

        # Overlay the bounding box for the tumour region.
        show_box(bbox, axes[i])
        
        # Compute and display the TP, FP, and FN regions for the current modality's prediction.
        true_positive = (seg_slice == 1) & (pred_scans[i][:, :, nslice] == 1)
        false_positive = (seg_slice == 0) & (pred_scans[i][:, :, nslice] == 1)
        false_negative = (seg_slice == 1) & (pred_scans[i][:, :, nslice] == 0)
        show_mask(true_positive, axes[i], colour=[0, 1, 0, 0.6])  # Green for TP
        show_mask(false_positive, axes[i], colour=[1, 0, 0, 0.6]) # Red for FP
        show_mask(false_negative, axes[i], colour=[0, 0, 1, 0.6]) # Blue for FN

    # Plot ground truth segmentation.
    axes[4].imshow(seg_slice, cmap='gray', vmin=0, vmax=1)
    axes[4].set_title('Ground Truth Segmentation')
    axes[4].axis('off')
    show_box(bbox, axes[4])

    # Plot predicted segmentation with a black background for contrast.
    axes[5].imshow(np.zeros_like(pred_slice), cmap='gray', vmin=0, vmax=1)
    axes[5].imshow(pred_slice, cmap='gray', vmin=0, vmax=1)
    axes[5].set_title('Overall Predicted Segmentation')
    axes[5].axis('off')
    axes[5].set_facecolor('black')
    show_box(bbox, axes[5])

    # Compute and display the TP, FP, and FN regions for the overall prediction.
    true_positive = (seg_slice == 1) & (pred_slice == 1)
    false_positive = (seg_slice == 0) & (pred_slice == 1)
    false_negative = (seg_slice == 1) & (pred_slice == 0)
    show_mask(true_positive, axes[5], colour=[0, 1, 0, 0.6])  # Green for TP
    show_mask(false_positive, axes[5], colour=[1, 0, 0, 0.6]) # Red for FP
    show_mask(false_negative, axes[5], colour=[0, 0, 1, 0.6]) # Blue for FN
    
    # Create a custom legend for TP, FP, and FN.
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor=[0, 1, 0, 0.6], edgecolor='w', label='True Positive'),
        Patch(facecolor=[1, 0, 0, 0.6], edgecolor='w', label='False Positive'),
        Patch(facecolor=[0, 0, 1, 0.6], edgecolor='w', label='False Negative')
    ]
    fig.legend(handles=legend_elements, loc='upper center', ncol=3, bbox_to_anchor=(0.5, 0.92), fontsize=12, frameon=False)

    # Adjust layout to prevent overlap of subplots and return the figure.
    plt.tight_layout(rect=[0, 0, 1, 0.9])
    return fig

def combined_plot_slices(seg=None, pred_scans=None, version="U-SAM-Combo"):
    """
    Plots MRI images and their respective ground truth and predicted segmentations,
    tailored for the U-SAM models that have different subfigures than plot_slices.

    This function displays a set of MRI images from multiple modalities (t1c, t1n, t2f, t2w), 
    ground truth segmentation, and predicted segmentation for a particular slice. It also 
    visualises True Positive (TP), False Positive (FP), and False Negative (FN) regions to 
    compare the model's performance.

    Args:
        seg (numpy array): Ground truth segmentation mask (H, W, D).
        pred_scans (list of numpy arrays): List of predicted segmentation masks for each modality (optional).
        version (str): The subtitle of the resulting plot.

    Returns:
        matplotlib.figure.Figure: The figure containing the plots for MRI slices and segmentations.
    """
    
    if (version == "U-SAM-Combo"):
        suffixes = ['U-Net', 'PEFT-SAM', 'Union', 'Intersection', 'Weighted']
    else: #(version == "U1-SAM2"):
        suffixes = ['U-Net', 'U-Net Input', 'PEFT-SAM', 'U1-SAM2 Output']

    # Determine the slice with the largest tumour cross-section.
    nslice = max_slice(seg)

    # Extract the corresponding ground truth segmentation for the selected slice.
    seg_slice = seg[:, :, nslice]

    # Generate a bounding box around the tumour region with a margin of 3.
    bbox = np.array(generate_bbox(seg_slice, margin=3))

    # Create subplots to display the images and segmentations.
    fig, axes = plt.subplots(1, 6, figsize=(15, 5))
    fig.suptitle(f'{version} Tumour Segmentation Analysis', fontsize=20)

    # Loop through each MRI modality and display the slice with overlaid masks.
    for i, suffix in enumerate(suffixes):

        if suffix == 'U-Net Input':
            im = axes[i].imshow(pred_scans[i][:, :, nslice], cmap='viridis')  # Use a colormap like 'viridis'
        else:
            axes[i].imshow(np.zeros_like(pred_scans[i][:, :, nslice]), cmap='gray', vmin=0, vmax=1)  # Set black background
            axes[i].imshow(pred_scans[i][:, :, nslice], cmap='gray', vmin=0, vmax=1)  # Plot predicted segmentation

            # Compute and display the TP, FP, and FN regions for the current modality's prediction.
            true_positive = (seg_slice == 1) & (pred_scans[i][:, :, nslice] == 1)
            false_positive = (seg_slice == 0) & (pred_scans[i][:, :, nslice] == 1)
            false_negative = (seg_slice == 1) & (pred_scans[i][:, :, nslice] == 0)
            show_mask(true_positive, axes[i], colour=[0, 1, 0, 0.6])  # Green for TP
            show_mask(false_positive, axes[i], colour=[1, 0, 0, 0.6]) # Red for FP
            show_mask(false_negative, axes[i], colour=[0, 0, 1, 0.6]) # Blue for FN

        axes[i].set_facecolor('black')
        axes[i].set_title(f'{suffix} Prediction')
        axes[i].axis('off')

        # Overlay the bounding box for the tumour region.
        show_box(bbox, axes[i])

    # Plot ground truth segmentation.
    axes[5].imshow(seg_slice, cmap='gray', vmin=0, vmax=1)
    axes[5].set_title('Ground Truth Segmentation')
    axes[5].axis('off')
    show_box(bbox, axes[5])

    # Create a custom legend for TP, FP, and FN.
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor=[0, 1, 0, 0.6], edgecolor='w', label='True Positive'),
        Patch(facecolor=[1, 0, 0, 0.6], edgecolor='w', label='False Positive'),
        Patch(facecolor=[0, 0, 1, 0.6], edgecolor='w', label='False Negative')
    ]
    fig.legend(handles=legend_elements, loc='upper center', ncol=3, bbox_to_anchor=(0.5, 0.92), fontsize=12, frameon=False)

    # Adjust layout to prevent overlap of subplots and return the figure.
    return fig

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Helper Functions for visualisation adapted from:
# https://colab.research.google.com/drive/1F6uRommb3GswcRlPZWpkAQRMVNdVH7Ww?usp=sharing#scrollTo=sH6NorejpTii

def show_mask(mask, ax, colour=False):
    """
    Displays a mask on a given matplotlib axis.
    
    Args:
        mask (numpy array): The mask to overlay.
        ax (matplotlib axis): The axis to display the mask on.
        colour (list or None): RGBA color for the mask overlay. Defaults to red.
    """
    if colour is None:
        colour = np.array([1, 0, 0, 0.6]) # Default colour is semi-transparent red.
    mask = mask.astype(float)
    mask_image = np.expand_dims(mask, axis=-1) * colour
    ax.imshow(mask_image)

def show_box(box, ax, colour='magenta'):
    """
    Displays a bounding box on a given matplotlib axis.

    Args:
        box (list): Bounding box coordinates [x0, y0, x1, y1].
        ax (matplotlib axis): The axis to display the bounding box on.
        colour (str): Color of the bounding box (default: magenta).
    """
    x0, y0 = box[0], box[1]
    w, h = box[2] - box[0], box[3] - box[1]
    ax.add_patch(plt.Rectangle((x0, y0), w, h, edgecolor=colour, facecolor=(0,0,0,0), lw=2))

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~