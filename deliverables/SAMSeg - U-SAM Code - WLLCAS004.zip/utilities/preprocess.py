"""
preprocess.py

Author: WLLCAS004
Date: July 4, 2024

Description:
This script implements preprocessing functions for MRI images in the BraTS dataset.
The main operations include Z-score normalization, rescaling, and center cropping.

Citations:
    - The Segment Anything Model (SAM).
    - BraTS Intracranial Meningioma 2023 Challenge Dataset.
    - NumPy, Scimage libraries.
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/processing/preprocess.py
"""

import numpy as np

from skimage import exposure

def znorm_rescale(img):
    """
    Applies Z-score normalisation, linear transformation, and intensity rescaling 
    to an MRI image.

    Args:
        img (ndarray): The input MRI image.
    
    Returns:
        ndarray: The normalised and rescaled image.
    """

    # Step 1: Z-Score Normalisation
    #-----------------------------------------------------------------------------
    # Make a copy of the image to avoid modifying the original.
    movingNan = np.copy(img)

    # Replace zero values with NaN to exclude them from mean/std calculation.
    movingNan[movingNan == 0] = np.nan

    # Calculate the mean and standard deviation of non-zero elements.
    movingMean = np.nanmean(movingNan)
    movingSTD = np.nanstd(movingNan)

    # Apply Z-score normalization: (img - mean) / std
    # Subtract the mean and divide by the standard deviation.
    moving = (img - movingMean) / movingSTD
    #-----------------------------------------------------------------------------

    # Step 2: Linear Transformation
    #-----------------------------------------------------------------------------
    # Scale the normalized values to a specific range -> [0; 255].
    # This is based on a linear transformation of the normalised image.
    b = 255 / (1 - (moving.max() / moving.min())) # Scale factor.
    a = -b / moving.min() # Offset

    # Apply linear transformation to the normalised image.
    movingNorm = np.copy(moving)
    movingNorm = np.round((movingNorm * a) +b, 2)
    #-----------------------------------------------------------------------------

    # Step 3: Rescaling
    #-----------------------------------------------------------------------------
    # Rescale the intensity values using percentiles to enhance contrast.
    # The 1st and 99th percentiles of the transformed values are commonly used, but this could be tuned.
    p2, p98 = np.percentile(movingNorm, (1, 99)) 

    # Rescale intensities to the range [0, 1] based on the percentiles.
    moving_rescale = exposure.rescale_intensity(movingNorm, in_range=(p2, p98))
    #-----------------------------------------------------------------------------

    return moving_rescale

# Predefined crop ranges for center cropping the MRI volumes.
# This was found by trial-and-error - the most optimal centre-cropping
# without cutting into any brain boundary in any sample.
X_START, X_END, Y_START, Y_END, Z_START, Z_END = (51, 189, 19, 221, 9, 147)

def center_crop(img):
    """
    Center crops a 3D MRI image or segmentation mask to a fixed size (138, 202, 138).

    Args:
        img (ndarray): The input 3D image or segmentation mask.
    
    Returns:
        ndarray: The cropped image.
    """
    return img[X_START:X_END, Y_START:Y_END, Z_START:Z_END]

def undo_center_crop(input):
    """
    Restores the original size of a center-cropped MRI image or segmentation mask 
    by placing it back into a larger empty array with the original dimensions.

    Args:
        input (ndarray): The cropped 3D image or segmentation mask.
    
    Returns:
        ndarray: The image or segmentation mask with its original dimensions (240, 240, 155).
    """

    # Initialise an empty array with the original shape (240, 240, 155).
    out = np.zeros((240, 240, 155))

    # Place the cropped image back into its original location within the larger array.
    out[X_START:X_END, Y_START:Y_END, Z_START:Z_END] = input 
    
    return out