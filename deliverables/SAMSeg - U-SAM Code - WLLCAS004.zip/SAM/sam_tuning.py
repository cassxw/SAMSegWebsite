"""
sam_tuning.py

Author: WLLCAS004
Date: July 4, 2024

Description:
This script performs hyperparameter tuning for a segmentation model using Optuna. SAM, is trained and validated on
3D medical images, with the objective of maximizing the Dice score.

Optuna is used to optimise learning rate, number of samples per epoch, and other model parameters. The model's 
performance is evaluated based on Dice metric scores, and model checkpoints are saved when improvements are detected.

CLI Parameters:
    --checkpoint_path: Path to the model checkpoint for tune for.
    --output_dir: Directory to save the tuned models and checkpoints.
    --n_trials: Number of Optuna trials to perform (default: 100).

$ python3 SAM/sam_tuning.py --checkpoint_path checkpoints/sam_vit_b_01ec64.pth --output_dir SAM/tuning_outputs --n_trials 50

Citations:
    - Segment Anything Model (SAM)
    - BraTS Intracranial Meningioma 2023 Challenge Dataset
    - PyTorch libraries
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/model_routines/train.py
"""
import os
import torch
import optuna
import argparse

from torch import optim
import torch.nn as nn

from utilities.model_utils import load_or_initialise_training, make_dataloader, exp_decay_learning_rate, train_one_epoch, validate_one_epoch

from segment_anything import sam_model_registry

VANILLA_PATH = './checkpoints/sam_vit_b_01ec64.pth'
TRAINING_SET_DIR = './dataset/BraTS-MEN-Train'
TESTING_SET_DIR = './dataset/BraTS-MEN-Test'
VALIDATION_SET_DIR = './dataset/BraTS-MEN-Validate'

def objective(trial, checkpoint_path, output_dir):
    """
    Objective function for Optuna's hyperparameter optimisation.
    This function performs training and validation of the SAM model on 3D medical images using the hyperparameters 
    sampled by the Optuna trial. It returns the best Dice score achieved during validation.

    Parameters:
        trial: Optuna trial object that provides sampled hyperparameters.
        checkpoint_path (str): Path to a model checkpoint for resuming training.
        output_dir (str): Directory to save model checkpoints.

    Returns:
        best_validation_dice (float): The best Dice score achieved during validation.
    """
    DEVICE = torch.device('cuda:0')

    # If output directory doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        os.system(f'chmod a+rwx {output_dir}')

    # Sample hyperparameters using Optuna's search space.
    init_lr = trial.suggest_loguniform('init_lr', 1e-9, 1e-4)
    num_samples_per_epoch = trial.suggest_int('num_samples_per_epoch', 50, 175)
    decay_rate = trial.suggest_float('decay_rate', 0.01, 1.0)
    max_epoch = trial.suggest_int('max_epoch', 10, 100)

    # Initialise the SAM model and move it to GPU.
    model = sam_model_registry['vit_b'](checkpoint=None)
    model.to(DEVICE)
    
    # Define loss functions and weights.    
    loss_functions = [nn.MSELoss(), nn.CrossEntropyLoss()]
    loss_weights = [0.4, 0.7]

    # Set up the optimiser for model parameters.
    optimiser = optim.Adam(model.mask_decoder.parameters(), lr=init_lr, weight_decay=0, amsgrad=True)

    # Load model state and optimiser state, if a checkpoint is provided.
    epoch_start, best_vloss, best_dice = load_or_initialise_training(model, optimiser, checkpoint_path, train_with_val=True)
    
    # Create data loaders for training and validation.
    train_loader = make_dataloader(TRAINING_SET_DIR, shuffle=True, mode='train', batch_size=1)
    val_loader = make_dataloader(VALIDATION_SET_DIR, shuffle=False, mode='train', batch_size=1)

    for epoch in range(epoch_start,  epoch_start+max_epoch):

        # Apply learning rate decay.
        exp_decay_learning_rate(optimiser, epoch, init_lr, decay_rate)

        # Train for one epoch and compute the average training loss.
        average_epoch_loss = train_one_epoch(model, optimiser, train_loader, loss_functions, loss_weights, num_samples_per_epoch)
        print(f'Epoch {epoch} completed. Average loss = {average_epoch_loss}.')

        # Validate the model every 5 epochs.
        if epoch % 5 == 0:
            average_val_loss, mean_validation_dice = validate_one_epoch(model, val_loader, loss_functions, loss_weights)
            print(f'Epoch {epoch} validation completed. Average validation loss = {average_val_loss}.')

            # Update best validation loss and Dice score if improved.
            if average_val_loss < best_vloss:
                best_vloss = average_val_loss
            if mean_validation_dice > best_dice:
                best_dice = mean_validation_dice

        # Save model checkpoint for each epoch.
        print('Saving model checkpoint...')
        checkpoint = {
            'epoch': epoch,
            'model_sd': model.state_dict(),
            'optim_sd': optimiser.state_dict(),
            'model': model,
            'loss_functions': loss_functions,
            'loss_weights': loss_weights,
            'init_lr': init_lr,
            'decay_rate': decay_rate,
            'vloss': best_vloss,
            'dice': best_dice
        }
        torch.save(checkpoint, os.path.join(output_dir, f'epoch_{epoch}_{best_dice}.pth.tar'))

        # Report progress to Optuna.
        trial.report(mean_validation_dice, epoch)
        if trial.should_prune():
            raise optuna.TrialPruned()

    return best_dice

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Hyperparameter Tuning for SAM Model using Optuna.')
    
    parser.add_argument('--checkpoint_path', type=str, default=None, help='Initial checkpoint for resuming training')
    parser.add_argument('--output_dir', type=str, default=None, help='Directory to save tuning checkpoints')
    parser.add_argument('--n_trials', type=int, default=100, help='Number of Optuna trials')
    
    args = parser.parse_args()

    # Set up the Optuna study for optimisation.
    study = optuna.create_study(direction='maximize')
    study.optimize(lambda trial: objective(trial, args.checkpoint_path, args.output_dir), n_trials=args.n_trials)

    # Output the best trial results.
    print('Best trial:')
    trial = study.best_trial
    print(f'  Value: {trial.value}')
    print('  Params: ')
    for key, value in trial.params.items():
        print(f'    {key}: {value}')