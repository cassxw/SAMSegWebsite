"""
sam_test.py

Author: WLLCAS004
Date: July 5, 2024

Description:
This script tests the Vanilla Segment Anything Model (SAM) or a PEFT-SAM version on our Testing Set.
It evaluates model performance  by calculating loss metrics such as the Dice Score, and optionally
visualising segmentation results.

CLI Parameters:
    --vanilla: Boolean flag to specify whether to test Vanilla SAM (default: False).
    --peft_path: Path to the PEFT-SAM model checkpoint (only required if --vanilla not set)
    --visualise: Boolean flag to specify if predictions should be visualised and saved as plots.
    --results_dir: Directory to save visualizations (only required if --visualise is set).
    --validate: Boolean flag to specify whether to run on the Validation Set, instead of Testing.

Testing/Validating Vanilla Use-Case:
$ python3 SAM/sam_test.py --vanilla --visualise --results_dir SAM/vanilla_test_results --batch_size 1
$ python3 SAM/sam_test.py --vanilla --visualise --results_dir SAM/vanilla_val_results --batch_size 1 --validate

Testing/Validating PEFT-SAM Use-Case:
$ python3 SAM/sam_test.py --peft_path checkpoints/peft-sam_epoch_125.pth.tar --visualise --results_dir SAM/peft_test_results --batch_size 1
$ python3 SAM/sam_test.py --peft_path checkpoints/peft-sam_epoch_125.pth.tar --visualise --results_dir SAM/peft_val_results --batch_size 1 --validate

Citations:
    - The Segment Anything Model (SAM).
    - BraTS Intracranial Meningioma 2023 Challenge Dataset.
    - PyTorch, NumPy, Monai libraries.
    - https://github.com/KurtLabUW/brats2023_updated/blob/master/model_routines/validate.py
    
"""

import os
import argparse
import numpy as np

import torch
import torch.nn as nn

from monai.metrics import DiceMetric

from utilities.model_utils import make_dataloader, compute_loss
from utilities.general_utils import probs_to_preds, seg_to_binary, generate_bbox, save_pred_as_nifti
from utilities.plot import plot_slices

from segment_anything import SamPredictor, sam_model_registry

# Default model checkpoint (Vanilla SAM).
VANILLA_PATH = './checkpoints/sam_vit_b_01ec64.pth'
TESTING_SET_DIR = './dataset/BraTS-MEN-Test'
VALIDATION_SET_DIR = './dataset/BraTS-MEN-Validate'

#------------------------------------------------------------------------------------------------------------------------------------
def test(checkpoint_path=VANILLA_PATH, results_dir=None, make_visuals=False, batch_size=1, using_vanilla=False, on_validation=False):
    """
    Test Vanilla SAM or a PEFT-SAM version on our Testing Set.

    Args:
        checkpoint_path (str): Path of trained model checkpoint.
        results_dir (str): Output directory for saving plots (if any). Defaults to current working directory.
        make_visuals (bool): Flag to determine whether to plot predictions. Defaults to False.
        batch_size (int): Batch size for the dataloader. Defaults to 1.
        using_vanilla (bool): Flag to indicate if vanilla SAM is used. Defaults to False.
        on_validation (bool): Flag to indicate if to predict on Validation instead of Testing.
    """

    # Set up output directories.
    if results_dir is None:
        results_dir = os.getcwd()

    if make_visuals:
        plots_dir = os.path.join(results_dir, 'plots')
        if not os.path.exists(plots_dir):
            os.makedirs(plots_dir)                  # Create the directory if it doesn't exist.
            os.system(f'chmod a+rwx {plots_dir}')   # Ensure permissions for the directory.

    #--------------------------------------------------------------------
    # Load the model.
    
    # Initialise SAM model.
    model = sam_model_registry['vit_b'](checkpoint=None)

    # Determine if using Vanilla or PEFT-SAM.
    if using_vanilla:
        print("Loading Vanilla SAM...")
        checkpoint = torch.load(VANILLA_PATH)
        model.load_state_dict(checkpoint) # Vanilla SAM loading.
    else:
        print(f"Loading model from {checkpoint_path}...")
        checkpoint = torch.load(checkpoint_path)
        model.load_state_dict(checkpoint['model_sd']) # PEFT-SAM loading.

    # Move model to GPU.
    model.cuda()
    model.eval()
    predictor = SamPredictor(model)

    # Loss function definitions.
    loss_functions = [nn.MSELoss(), nn.CrossEntropyLoss()]
    loss_weights = [0.4, 0.7]
    #--------------------------------------------------------------------

    print(f"{'Vanilla' if using_vanilla else 'PEFT'} SAM Model loaded.\n")

    if (on_validation):
        print("Validation starts.")
        data_dir = VALIDATION_SET_DIR
    else:
        print("Testing starts.")
        data_dir = TESTING_SET_DIR

    print("---------------------------------------------------")
    print(f"TRAINING SUMMARY")
    print(f"Model: {model}")
    print(f"Loss functions: {loss_functions}") 
    print(f"Loss weights: {loss_weights}")
    print("---------------------------------------------------")
    print("TESTING SUMMARY")
    print(f"Data directory: {data_dir}")
    print(f"Trained model checkpoint path: {checkpoint_path}")
    print(f"Out directory: {results_dir}")
    print(f"Make plots: {make_visuals}")
    print(f"Batch size: {batch_size}")
    print("---------------------------------------------------\n")

    # DataLoader Setup.
    test_loader = make_dataloader(data_dir, shuffle=False, mode='train', batch_size=batch_size)

    # Hold Testing Loss values for each scan type.
    test_loss_vals = []
    test_loss_vals_t1c = []
    test_loss_vals_t1n = []
    test_loss_vals_t2f = []
    test_loss_vals_t2w = []

    # Dice Metric Set Up, for each scan type.
    dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    dice_metric_t1c = DiceMetric(include_background=True, reduction="mean_batch")
    dice_metric_t1n = DiceMetric(include_background=True, reduction="mean_batch")
    dice_metric_t2f = DiceMetric(include_background=True, reduction="mean_batch")
    dice_metric_t2w = DiceMetric(include_background=True, reduction="mean_batch")

    DEVICE = torch.device("cuda:0")

    # Testing Loop.
    with torch.no_grad():
        for sample_names, imgs, seg in test_loader:

            # Move inputs to GPU.
            imgs = [img.cuda() for img in imgs] # [Bx1xHxWxD]
            seg = seg.cuda()                    # [Bx1xHxWxD]

            # Convert ground truth to binary segmentation mask.
            seg = seg_to_binary(seg) # [Bx1xHxWxD]
            # Now, each voxel in seg is either 0 (Not Tumour) or 1 (Tumour).

            # Expand single-channel images to 3-channel (RGB).
            imgs = [torch.cat([img, img, img], dim=1) for img in imgs] # [Bx3xHxWxD]

            # Initialise output tensors for each scan type to be the same shape as seg.
            output = torch.zeros_like(seg).to(DEVICE)       # [Bx1xHxWxD]
            output_t1c = torch.zeros_like(seg).to(DEVICE)   # [Bx1xHxWxD]
            output_t1n = torch.zeros_like(seg).to(DEVICE)   # [Bx1xHxWxD]
            output_t2f = torch.zeros_like(seg).to(DEVICE)   # [Bx1xHxWxD]
            output_t2w = torch.zeros_like(seg).to(DEVICE)   # [Bx1xHxWxD]

            # Process each slice along the depth dimension.
            for slice_idx in range(seg.shape[4]):

                # Extract the 2D binary mask for the current slice.
                seg_slice = seg[:, :, :, :, slice_idx] # [Bx1xHxW]

                # Check if this slice contains any tumour.
                if seg_slice.sum() > 0:

                    # Initialise the combined output mask to be the same shape as seg_slice.
                    combined_output_slice = torch.zeros_like(seg_slice).to(DEVICE)      # [Bx1xHxW]
                    combined_output_slice_t1c = torch.zeros_like(seg_slice).to(DEVICE)  # [Bx1xHxW]
                    combined_output_slice_t1n = torch.zeros_like(seg_slice).to(DEVICE)  # [Bx1xHxW]
                    combined_output_slice_t2f = torch.zeros_like(seg_slice).to(DEVICE)  # [Bx1xHxW]
                    combined_output_slice_t2w = torch.zeros_like(seg_slice).to(DEVICE)  # [Bx1xHxW]

                    # Generate the bounding box for the current slice.
                    bbox_coord = np.array(generate_bbox(seg_slice[0, 0, :, :].cpu().numpy(), margin=0))

                    # Process each scan type.
                    for scan_type in range(4):
                        
                        img_slice = imgs[scan_type][0, :, :, :, slice_idx].permute(1, 2, 0).cpu().numpy() # (H,W,C)

                        # Set the image for prediction.
                        predictor.set_image(img_slice, "RGB")
                        
                        # Run SAM prediction, using bounding box prompt.
                        slice_output, _, _ = predictor.predict(
                            box=bbox_coord,
                            multimask_output=False,
                        )
                        # slice_output shape is (C,H,W).

                        # Convert slice_output to tensor.
                        slice_output = torch.tensor(slice_output, device=DEVICE).unsqueeze(0) # [B,C,H,W]

                        # Combine the current slice output with the combined mask using a union operation.
                        combined_output_slice = torch.max(combined_output_slice, slice_output)

                        if (scan_type == 0):
                            combined_output_slice_t1c = torch.max(combined_output_slice_t1c, slice_output)
                        elif (scan_type == 1):
                            combined_output_slice_t1n = torch.max(combined_output_slice_t1n, slice_output)
                        elif (scan_type == 2):
                            combined_output_slice_t2f = torch.max(combined_output_slice_t2f, slice_output)
                        elif (scan_type == 3):
                            combined_output_slice_t2w = torch.max(combined_output_slice_t2w, slice_output)
                        
                    # Add the slice_output to the correct slice in output.
                    output[:, :, :, :, slice_idx] = combined_output_slice
                    output_t1c[:, :, :, :, slice_idx] = combined_output_slice_t1c
                    output_t1n[:, :, :, :, slice_idx] = combined_output_slice_t1n
                    output_t2f[:, :, :, :, slice_idx] = combined_output_slice_t2f
                    output_t2w[:, :, :, :, slice_idx] = combined_output_slice_t2w

            # output shape is:  [B,C,H,W,D]
            # seg shape is:     [B,C,H,W,D]

            # Compute weighted loss for each scan type.
            val_loss = compute_loss(output, seg, loss_functions, loss_weights)
            test_loss_vals.append(val_loss.detach().cpu())

            val_loss_t1c = compute_loss(output_t1c, seg, loss_functions, loss_weights)
            test_loss_vals_t1c.append(val_loss_t1c.detach().cpu())

            val_loss_t1n = compute_loss(output_t1n, seg, loss_functions, loss_weights)
            test_loss_vals_t1n.append(val_loss_t1n.detach().cpu())

            val_loss_t2f = compute_loss(output_t2f, seg, loss_functions, loss_weights)
            test_loss_vals_t2f.append(val_loss_t2f.detach().cpu())

            val_loss_t2w = compute_loss(output_t2w, seg, loss_functions, loss_weights)
            test_loss_vals_t2w.append(val_loss_t2w.detach().cpu())

            # Convert probabilities to binary predictions for Dice calculation.
            preds = probs_to_preds(output)          # [B,C,H,W,D]
            preds_t1c = probs_to_preds(output_t1c)  # [B,C,H,W,D]
            preds_t1n = probs_to_preds(output_t1n)  # [B,C,H,W,D]
            preds_t2f = probs_to_preds(output_t2f)  # [B,C,H,W,D]
            preds_t2w = probs_to_preds(output_t2w)  # [B,C,H,W,D]

            # Compute metrics between seg_eval and preds_eval.
            dice_metric(y_pred=preds, y=seg)
            dice_metric_t1c(y_pred=preds_t1c, y=seg)
            dice_metric_t1n(y_pred=preds_t1n, y=seg)
            dice_metric_t2f(y_pred=preds_t2f, y=seg)
            dice_metric_t2w(y_pred=preds_t2w, y=seg)

            # Visualisation (optional)
            if make_visuals:

                # Make plots for each sample in batch.
                for i, sample_name in enumerate(sample_names):

                    batch_imgs = [img[i, 0].cpu().detach() for img in imgs]

                    seg_plot = seg[i, 0].cpu().detach().numpy()
                    pred_plot = preds[i, 0].cpu().detach().numpy()
                
                    pred_plot_t1c = preds_t1c[i, 0].cpu().detach().numpy()
                    pred_plot_t1n = preds_t1n[i, 0].cpu().detach().numpy()
                    pred_plot_t2f = preds_t2f[i, 0].cpu().detach().numpy()
                    pred_plot_t2w = preds_t2w[i, 0].cpu().detach().numpy()

                    pred_scans = []
                    pred_scans.append(pred_plot_t1c)
                    pred_scans.append(pred_plot_t1n)
                    pred_scans.append(pred_plot_t2f)
                    pred_scans.append(pred_plot_t2w)

                    fig = plot_slices(batch_imgs, seg_plot, pred_plot, pred_scans, version=checkpoint_path)
                    fig.savefig(os.path.join(plots_dir, sample_name))

                    # Save overall pred as NIFTI.
                    save_pred_as_nifti(pred_plot, plots_dir, data_dir, sample_name)

    # Compute and report average and per scan type testing loss.
    average_val_loss = np.mean(test_loss_vals)
    average_val_loss_t1c = np.mean(test_loss_vals_t1c)
    average_val_loss_t1n = np.mean(test_loss_vals_t1n)
    average_val_loss_t2f = np.mean(test_loss_vals_t2f)
    average_val_loss_t2w = np.mean(test_loss_vals_t2w)

    print(f'\nCompleted.')
    print(f'Average Overall Loss = {average_val_loss}')
    print(f'Average t1c Loss = {average_val_loss_t1c}')
    print(f'Average t1n Loss = {average_val_loss_t1n}')
    print(f'Average t2f Loss = {average_val_loss_t2f}')
    print(f'Average t2w Loss = {average_val_loss_t2w}')

    print(f'\nOverall Dice Score = {dice_metric.aggregate().item()}')
    print(f't1c Dice Score = {dice_metric_t1c.aggregate().item()}')
    print(f't1n Dice Score = {dice_metric_t1n.aggregate().item()}')
    print(f't2f Dice Score = {dice_metric_t2f.aggregate().item()}')
    print(f't2w Dice Score = {dice_metric_t2w.aggregate().item()}')
#-----------------------------------------------------------------------------------------------------------------------------

# CLI setup using argparse.
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Test Vanilla SAM or a PEFT-SAM version on our Testing Set.')

    parser.add_argument('--vanilla', action='store_true', help='Flag to test Vanilla SAM (default: PEFT-SAM)')
    parser.add_argument('--peft_path', type=str, default=VANILLA_PATH, help='Path to the PEFT-SAM model checkpoint. (default: Vanilla SAM)')
    parser.add_argument('--visualise', action='store_true', help='Flag to visualise predictions')
    parser.add_argument('--results_dir', type=str, help='Directory to save visualisations (required if --visualise is set)')
    parser.add_argument('--batch_size', type=int, default=1, help='Batch size for testing')
    parser.add_argument('--validate', action='store_true', help='Flag to predict on the Validation Set instead')

    args = parser.parse_args()

    if args.visualise and not args.results_dir:
        raise ValueError("Please provide --results_dir if --visualise is set.")

    test(checkpoint_path=args.peft_path, results_dir=args.results_dir, make_visuals=args.visualise, batch_size=args.batch_size, using_vanilla=args.vanilla, on_validation=args.validate)