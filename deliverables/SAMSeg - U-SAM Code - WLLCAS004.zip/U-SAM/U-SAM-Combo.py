"""
U-SAM-Combo.py

Author: WLLCAS004
Date: July 15, 2024

Description:
This script combines segmentation results from U-Net and SAM to perform robust medical image segmentation.
It computes the union, intersection, and a weighted combination of the outputs from U-Net and SAM.
Additionally, it evaluates the performance of each method and their combinations using the Dice,
which is a measure of overlap between predicted and ground truth segmentations.
The script also supports optional visualisation of the results and saving the outputs in the specified directory.

CLI Parameters:
    --unet_checkpoint: Path to the U-Net model checkpoint file.
    --sam_checkpoint: Path to the SAM model checkpoint file.
    --bbox_emulation: Enable/Disable bounding box emulation for U-Net. Bounding box emulation is applied to slices without tumor regions.
    --visualise: Flag to enable result visualisations.
    --output_dir: Directory to save the output predictions, plots, and NIFTI files.

$ python3 U-SAM/U-SAM-Combo.py  --unet_checkpoint checkpoints/unet_epoch_100.pth.tar --sam_checkpoint checkpoints/peft-sam_epoch_125.pth.tar
                                --visualise --output_dir U-SAM/u-sam-combo-results
                                --bbox_emulation

Citations:
    - Segment Anything Model (SAM)
    - BraTS Intracranial Meningioma 2023 Challenge Dataset
    - NumPy, PyTorch, Monai libraries
"""
import sys
sys.path.append('UNet')

import os
import argparse
import numpy as np

import torch
from monai.metrics import DiceMetric

from segment_anything import SamPredictor, sam_model_registry

from UNet.unet3d import U_Net3d
from utilities.model_utils import make_dataloader
from utilities.general_utils import one_hot_channels_to_three_labels, unet_seg_to_one_hot_channels, unet_disjoint_to_overlapping, unet_probs_to_preds, probs_to_preds, seg_to_binary, generate_bbox, save_pred_as_nifti
from utilities.plot import combined_plot_slices

VANILLA_PATH = './checkpoints/sam_vit_b_01ec64.pth'
TESTING_SET_DIR = './dataset/BraTS-MEN-Test'

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def unet_sam_combined(unet_model, sam_predictor, with_bbox_emulation=True, make_visuals=False, output_dir=None):
    """
    Combines U-Net and SAM segmentations and evaluates their performance on the testing dataset.
    The function generates segmentation predictions using U-Net and SAM for each input scan, and then computes
    the union, intersection, and a weighted combination of the predictions. It calculates the Dice coefficient
    for each method and combination, and optionally visualises the results and saves them as NIFTI files.

    Args:
        unet_model (torch.nn.Module): The pre-trained U-Net model for segmentation.
        sam_predictor (SamPredictor): The SAM model for segmentation predictions using bounding boxes.
        with_bbox_emulation (bool): If True, U-Net uses bounding box emulation on slices without tumors.
        make_visuals (bool): If True, visualizes the predictions and saves the plots.
        output_dir (str): Directory to save the output plots and NIFTI files.
    """

    # Create output directory if it does not exist.
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
        os.system(f'chmod a+rwx {output_dir}')

    # Load the testing data.
    test_loader = make_dataloader(TESTING_SET_DIR, shuffle=False, mode='train')

    # Initialise Dice metrics for evaluating different output types.
    unet_current_dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    
    unet_dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    sam_dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    union_dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    intersection_dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    weighted_dice_metric = DiceMetric(include_background=True, reduction="mean_batch")

    DEVICE = torch.device("cuda:0")
    print("U-SAM-Combo Testing begins.")

    # Disable gradients for evaluation.
    with torch.no_grad():
        for sample_names, imgs, seg in test_loader:

            # Move input images and segmentation to GPU
            imgs = [img.cuda() for img in imgs] # [Bx1xHxWxD]
            seg = seg.cuda() # [Bx1xHxWxD]

            #------------------------------------------------------------------------------------------------------
            # U-NET PREDICTION
            #------------------------------------------------------------------------------------------------------

            # Convert the segmentation labels to one-hot encoded format for multi-class segmentation.
            unet_seg = unet_seg_to_one_hot_channels(seg) # [Bx3xHxWxD]

            # Concatenate all modalities along the channel axis.
            x_in = torch.cat(imgs, dim=1) # [Bx4xHxWxD]

            # Predict the segmentation using the U-Net model.
            unet_output = unet_model(x_in)
            unet_output = unet_output.float()

            #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            # Apply bounding box emulation to slices that do not contain any tumor region.
            if with_bbox_emulation:

                # Process each slice along the depth dimension.
                for slice_idx in range(unet_seg.shape[4]):
                    
                    # Extract the 2D binary mask for the current slice, only the WT.
                    seg_slice = unet_seg[:, :, :, :, slice_idx]

                    # Check if current slice does not contain any tumour.
                    if not seg_slice.sum() > 0:

                        # Zero out the current slice in the output if no tumour is found.
                        unet_output[:, :, :, :, slice_idx] = 0
            #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            # Convert probabilities to binary prediction.
            unet_preds = unet_probs_to_preds(unet_output, "overlapping")

            # Prediction conversion.
            seg_eval = unet_disjoint_to_overlapping(unet_seg)     # [Bx3xHxWxD]
            preds_eval = unet_disjoint_to_overlapping(unet_preds) # [Bx3xHxWxD]

            # Calculate Dice score for U-Net.
            unet_dice_metric(y_pred=preds_eval, y=seg_eval)
            #------------------------------------------------------------------------------------------------------

            #------------------------------------------------------------------------------------------------------
            # SAM PREDICTION
            #------------------------------------------------------------------------------------------------------
            # Convert ground truth segmentation to binary mask.
            sam_seg = seg_to_binary(seg) # [Bx1xHxWxD]
            # Now, each voxel in seg is either 0 (Not Tumour) or 1 (Tumour).

            # Expand single-channel images to 3-channel (RGB).
            imgs = [torch.cat([img, img, img], dim=1) for img in imgs] # [Bx3xHxWxD]

            # Initialise the output tensor to be the same shape as sam_seg.
            sam_output = torch.zeros_like(sam_seg).to(DEVICE) # [Bx1xHxWxD]

            # Process each slice along the depth dimension.
            for slice_idx in range(sam_seg.shape[4]):

                # Extract the 2D binary mask for the current slice.
                seg_slice = sam_seg[:, :, :, :, slice_idx] # [Bx1xHxW]

                # Check if this slice contains any tumour.
                if seg_slice.sum() > 0:

                    # Initialise the combined output mask to be the same shape as seg_slice.
                    sam_output_slice = torch.zeros_like(seg_slice).to(DEVICE) # [Bx1xHxW]

                    # Generate the bounding box for the current slice.
                    bbox_coord = np.array(generate_bbox(seg_slice[0, 0, :, :].cpu().numpy(), margin=0))

                    # Run SAM prediction for each scan type.
                    for scan_type in range(4):

                        img_slice = imgs[scan_type][0, :, :, :, slice_idx].permute(1, 2, 0).cpu().numpy()

                        # Set the image for prediction.
                        sam_predictor.set_image(img_slice, "RGB")

                        # Run SAM prediction, using bounding box prompt.
                        sam_slice_output, _, _ = sam_predictor.predict(
                            box=bbox_coord,
                            multimask_output=False
                        )
                        # slice_output shape is (C,H,W).

                        # Convert slice_output to tensor.
                        sam_slice_output = torch.tensor(sam_slice_output, device=DEVICE).unsqueeze(0)

                        # Combine the current slice output with the combined mask using a union operation.
                        sam_output_slice = torch.max(sam_output_slice, sam_slice_output)

                    # Add the slice_output to the correct slice in output.
                    sam_output[:, :, :, :, slice_idx] = sam_output_slice

            # Convert SAM prediction probabilities to binary prediction.
            sam_preds = probs_to_preds(sam_output)

            # Calculate Dice score for SAM.
            sam_dice = sam_dice_metric(y_pred=sam_preds, y=sam_seg).item()
            #------------------------------------------------------------------------------------------------------

            #------------------------------------------------------------------------------------------------------
            # COMBINED PREDICTION: Union, Intersection, Weighted
            #------------------------------------------------------------------------------------------------------
            # Extract the 0:1 Whole Tumour Channel from preds_eval.
            unet_output = preds_eval[:, 0, :, :, :].unsqueeze(1).to(DEVICE) # [BxWxHxD]
            unet_seg = seg_eval[:, 0, :, :, :].unsqueeze(1).to(DEVICE)      # [BxWxHxD]

            # Compute the Dice score for U-Net's current sample.
            unet_dice = unet_current_dice_metric(y_pred=unet_output, y=unet_seg).item() #U-Net dice for current sample,
            
            # Union------------------------------------------
            union_output = torch.max(unet_output, sam_output)
            union_preds = probs_to_preds(union_output)
            union_dice_metric(y_pred=union_preds, y=sam_seg)

            # Intersection-----------------------------------------------
            intersection_output = torch.min(unet_output, sam_output)
            intersection_preds = probs_to_preds(intersection_output)
            intersection_dice_metric(y_pred=intersection_preds, y=sam_seg)

            # Weighted-----------------------------------------------------------------
            # Calculate normalised weights based on Dice scores.
            total_dice_score = unet_dice + sam_dice
            unet_weight = unet_dice / total_dice_score
            sam_weight = sam_dice / total_dice_score

            # Compute combined weighted output
            weighted_output = (unet_weight * unet_output) + (sam_weight * sam_output)
            weighted_preds = probs_to_preds(weighted_output)
            weighted_dice_metric(y_pred=weighted_preds, y=sam_seg)
            #------------------------------------------------------------------------------------------------------

            # Visualisation (optional)
            if make_visuals:

                for i, sample_name in enumerate(sample_names):
                    seg_plot = sam_seg[i, 0].cpu().detach().numpy()

                    pred_scans = [
                        (one_hot_channels_to_three_labels(unet_preds[i]) > 0).numpy().astype(np.uint8),
                        (sam_preds[i, 0].cpu().detach().numpy() > 0).astype(np.uint8),
                        (union_preds[i, 0].cpu().detach().numpy() > 0).astype(np.uint8),
                        (intersection_preds[i, 0].cpu().detach().numpy() > 0).astype(np.uint8),
                        (weighted_preds[i, 0].cpu().detach().numpy() > 0).astype(np.uint8)
                    ]

                    # Plot and Save
                    fig = combined_plot_slices(seg_plot, pred_scans, version="U-SAM-Combo")
                    fig.savefig(os.path.join(output_dir, sample_name))

                    # Save the (union) predictions as NIFTI files in the output directory.
                    save_pred_as_nifti((union_preds[i, 0].cpu().detach().numpy() > 0).astype(np.uint8), output_dir, TESTING_SET_DIR, sample_name)

    print(f'\nU-SAM-Combo Testing completed!\n')

    # Aggregate and report the Dice scores:
    dice_metric_batch = unet_dice_metric.aggregate()
    eval_region_dice_scores = []
    for i in range(3):
        eval_region_dice_scores.append(dice_metric_batch[i].item())
        print(f"U-Net Dice Score {i}: {dice_metric_batch[i].item()}")

    print(f'\nSAM Dice Score = {sam_dice_metric.aggregate().item()}')

    print(f'\nUnion Dice Score = {union_dice_metric.aggregate().item()}')
    print(f'\nIntersection Dice Score = {intersection_dice_metric.aggregate().item()}')
    print(f'\nWeighted Dice Score = {weighted_dice_metric.aggregate().item()}')
    
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="U-Net and SAM Combined Testing Script")

    parser.add_argument("--unet_checkpoint", type=str, required=True,
        help="Path to the pre-trained U-Net model checkpoint."
    )
    parser.add_argument("--sam_checkpoint", type=str, default=VANILLA_PATH,
        help="Path to the pre-trained SAM model checkpoint."
    )
    parser.add_argument("--bbox_emulation", action="store_true", 
        help="Enable bounding box emulation for U-Net."
    )
    parser.add_argument("--visualise", action="store_true", 
        help="Enable visualisation of the results."
    )
    parser.add_argument("--output_dir", type=str, default="u-sam-combo-outputs",
        help="Directory to save output NIFTI files and visualisations."
    )

    args = parser.parse_args()
    DEVICE = torch.device("cuda:0")

    # U-Net Model Setup.
    unet_model = U_Net3d()
    checkpoint = torch.load(args.unet_checkpoint)
    model_sd = checkpoint['model_sd']
    unet_model.load_state_dict(model_sd)
    unet_model.to(DEVICE)

    # SAM Setup, with Predictor.
    sam_model = sam_model_registry['vit_b'](checkpoint=None)
    checkpoint = torch.load(args.sam_checkpoint)

    if (VANILLA_PATH in args.sam_checkpoint):
        sam_model.load_state_dict(checkpoint)
    else:
        sam_model.load_state_dict(checkpoint['model_sd'])

    sam_model.to(DEVICE)
    sam_predictor = SamPredictor(sam_model)

    print(f"Testing U-SAM-Combo (Union, Intersection, Weighted) with\nU-Net Version: {args.unet_checkpoint}\nSAM Version: {args.sam_checkpoint}\n")
    unet_sam_combined(unet_model, sam_predictor, with_bbox_emulation=args.bbox_emulation, make_visuals=args.visualise, output_dir=args.output_dir)