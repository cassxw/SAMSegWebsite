# Source: https://github.com/KurtLabUW/brats2023_updated/blob/master/model_routines/validate.py
# Date: July 5, 2024

import os
import numpy as np

import torch
import torch.nn as nn

from monai.metrics import HausdorffDistanceMetric, DiceMetric

from model_utils import make_dataloader, compute_loss
from general_utils import seg_to_one_hot_channels, disjoint_to_overlapping, probs_to_preds, one_hot_channels_to_three_labels, seg_to_binary, generate_bbox, save_pred_as_nifti
from plot import plot_slices

from segment_anything import SamPredictor, sam_model_registry

def validate(data_dir, ckpt_path, eval_regions='overlapping', out_dir=None, make_plots=False, batch_size=1):
    """Routine to validate a trained model on validation data. Optionally plots predictions against ground truth segmentations.
    
    Args:
        data_dir: Directory of validation data.
        ckpt_path: Path of trained model.
        eval_regions: Whether to evaluate on 'disjoint' or 'overlapping' regions. Defaults to 'overlapping'.
        out_dir: Directory in which to save plots. Defaults to None.
        make_plots: Whether to produce plots of predictions and ground truth segmentations. Defaults to False.
        batch_size: Batch size of dataloader. Defaults to 1.
    """

    # Set up directories.
    if out_dir is None:
        out_dir = os.getcwd()

    if make_plots:
        plots_dir = os.path.join(out_dir, 'plots')
        if not os.path.exists(plots_dir):
            os.makedirs(plots_dir)
            os.system(f'chmod a+rwx {plots_dir}')

    print(f"Loading model from {ckpt_path}...")
    
    #---------------------------------------------------
    DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else 'cpu')
    
    model = sam_model_registry['vit_b'](checkpoint=None)
    checkpoint = torch.load(ckpt_path)
    # model.load_state_dict(checkpoint['model_sd'])
    model.load_state_dict(checkpoint)
    model.to(DEVICE)

    predictor = SamPredictor(model)

    loss_functions = [nn.MSELoss(), nn.CrossEntropyLoss()]
    loss_weights = [0.4, 0.7]
    #---------------------------------------------------

    print('Model loaded.')

    print("---------------------------------------------------")
    print(f"TRAINING SUMMARY")
    print(f"Model: {model}")
    print(f"Loss functions: {loss_functions}") 
    print(f"Loss weights: {loss_weights}")
    # print(f"Training regions: {training_regions}")
    # print(f"Epochs trained: {epoch}")
    print("---------------------------------------------------")
    print("VALIDATION SUMMARY")
    print(f"Data directory: {data_dir}")
    print(f"Trained model checkpoint path: {ckpt_path}")
    print(f"Evaluation regions: {eval_regions}")
    print(f"Out directory: {out_dir}")
    print(f"Make plots: {make_plots}")
    print(f"Batch size: {batch_size}")
    print("---------------------------------------------------")

    val_loader = make_dataloader(data_dir, shuffle=False, mode='train', batch_size=batch_size)

    val_loss_vals = []

    # Recommend use MONAI metrics set-up for different metrics (Cumulative Iterative)
    dice_metric = DiceMetric(include_background=True, reduction="mean_batch")
    hd_metric = HausdorffDistanceMetric(include_background=True, percentile=95, reduction="mean_batch")

    # Define counters for GOOD, MEDIUM, and BAD samples
    GOOD_count = 0
    MEDIUM_count = 0
    BAD_count = 0

    print('Validation starts.\n')
    with torch.no_grad():

        count = 1
        for subject_names, imgs, seg in val_loader:
            print(f'Sample {count}.')

            model.eval()

            # Move data to GPU.
            imgs = [img.to(DEVICE) for img in imgs] # img is B1HWD
            seg = seg.to(DEVICE)
            # = torch.Size([1, 1, 138, 202, 138])

            # Convert segmentation to binary mask.
            seg = seg_to_binary(seg) # seg is B1HWD - each voxel is either 0 (Not Tumour) or 1 (Tumour)
            # = torch.Size([1, 1, 138, 202, 138])

            # Convert every img to RGB by duplicates the single channel three times.
            imgs = [torch.cat([img, img, img], dim=1) for img in imgs]
            # = torch.Size([1, 3, 138, 202, 138])

            # Initialise the output tensor to be the same shape as seg_train.
            output = torch.zeros_like(seg).to(DEVICE)
            # = torch.Size([1, 1, 138, 202, 138])

            # Iterate through each slice along the depth dimension, i.e. index 4.
            for slice_idx in range(seg.shape[4]):

                # Extract the 2D binary mask for the current slice.
                seg_slice = seg[:, :, :, :, slice_idx]
                # = torch.Size([1, 1, 138, 202])

                # Check if this slice contains any tumour.
                if seg_slice.sum() > 0:  # If there are any tumour pixels...

                    # Initialise the combined output mask to be the same shape as seg_slice.
                    combined_output_slice = torch.zeros_like(seg_slice).to(DEVICE)
                    # = torch.Size([1, 1, 138, 202])

                    # Generate the bounding box for the current slice.
                    bbox_coord = np.array(generate_bbox(seg_slice[0, 0, :, :].cpu().numpy(), margin=0))

                    # Process each scan type.
                    for scan_type in range(4):
                        
                        img_slice = imgs[scan_type][0, :, :, :, slice_idx].permute(1, 2, 0).cpu().numpy()
                        # = (138, 202, 3)

                        # Set the image for prediction.
                        predictor.set_image(img_slice, "RGB")
                        
                        # Predict using the bounding box.
                        slice_output, _, _ = predictor.predict(
                            box=bbox_coord,
                            multimask_output=False,
                        )
                        # = (1, 138, 202)

                        # Convert slice_output to tensor.
                        slice_output = torch.tensor(slice_output, device=DEVICE).unsqueeze(0)
                        # = torch.Size([1, 1, 138, 202])

                        # Combine the current slice output with the combined mask using a union operation.
                        combined_output_slice = torch.max(combined_output_slice, slice_output)
                        
                    # Add the slice_output to the correct slice in output
                    output[0, 0, :, :, slice_idx] = combined_output_slice

            # output shape is:  torch.Size[1, 1, 138, 202, 138]
            # seg shape is:     torch.Size[1, 1, 138, 202, 138]

            # Compute weighted loss, summed across each training region.
            val_loss = compute_loss(output, seg, loss_functions, loss_weights, DEVICE)
            val_loss_vals.append(val_loss.detach().cpu())

            # Convert probabilities to binary predictions
            preds = probs_to_preds(output)
            # = torch.Size([1, 1, 138, 202, 138])

            # Compute metrics between seg_eval and preds_eval.
            dice_metric(y_pred=preds, y=seg)
            hd_metric(y_pred=preds, y=seg)

            # Compute the average Dice score
            dice_scores = dice_metric.aggregate().cpu().numpy()
            avg_dice_score = dice_scores.mean()
            
            # Update the GOOD, MEDIUM, BAD counters based on avg_dice_score
            if avg_dice_score >= 0.75:
                GOOD_count += 1
            elif avg_dice_score >= 0.50:
                MEDIUM_count += 1
            else:
                BAD_count += 1

            if make_plots:
                # Make plots for each subject in batch.
                for i, subject_name in enumerate(subject_names):

                    batch_imgs = [img[i, 0].cpu().detach() for img in imgs]
                    # seg3 = one_hot_channels_to_three_labels(seg[i].cpu().detach())
                    # pred3 = one_hot_channels_to_three_labels(preds[i])

                    seg_plot = seg[i, 0].cpu().detach().numpy()
                    pred_plot = preds[i, 0].cpu().detach().numpy()

                    fig = plot_slices(batch_imgs, seg_plot, pred_plot)
                    fig.savefig(os.path.join(plots_dir, subject_name))

                    # Save pred as NIFTI
                    save_pred_as_nifti(pred_plot, plots_dir, data_dir, subject_name)

            count += 1

    # Compute and report validation loss.
    average_val_loss = np.mean(val_loss_vals)
    print(f'\nTesting completed. Average testing loss = {average_val_loss}\n')

    print(f'Dice Score = {dice_metric.aggregate().item()}')
    print(f'HD95 = {hd_metric.aggregate().item()}')

    # Print the counts for GOOD, MEDIUM, and BAD samples
    print(f"\nGOOD samples: {GOOD_count}")
    print(f"MEDIUM samples: {MEDIUM_count}")
    print(f"BAD samples: {BAD_count}")

if __name__ == '__main__':

    data_dir = '/home/peter/Documents/Code/samseg/src/TumourSamples/GOOD_Samples'
    ckpt_path = '/home/peter/Documents/Code/samseg/src/sam_vit_b_01ec64.pth'
    out_dir = './test-out'

    validate(data_dir, ckpt_path, out_dir=out_dir, make_plots=True)