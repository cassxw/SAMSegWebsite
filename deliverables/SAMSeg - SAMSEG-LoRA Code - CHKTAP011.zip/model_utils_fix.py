# Source: https://github.com/KurtLabUW/brats2023_updated/blob/master/utils/model_utils.py
# Date: July 4, 2024

import os
import numpy as np
import torch
from torch.utils.data import DataLoader

import brats_dataset
import random

from general_utils import seg_to_binary, generate_bbox
from tqdm import tqdm
from preprocess import augment

from monai.metrics import DiceMetric

from torch.nn.functional import threshold, normalize

from segment_anything.utils.transforms import ResizeLongestSide
from segment_anything import build_sam_vit_b, SamPredictor
from src.lora import LoRA_sam

def find_slices(seg, skip = 0):
# """Finds the slice (in the z-direction) of a segmentation with the most tumour voxels."""

    """Finds the slice with the largest cross-sectional area of the tumor.

    Args:
        seg: The 3D segmentation tensor with shape [B, 1, H, W, D].

    Returns:
        The indices of slices with tumors present.
    """
    
    # Ensure seg is a numpy array.
    if not isinstance(seg, np.ndarray):
        seg_np = seg.cpu().numpy()
        seg_np = seg_np.squeeze(0).squeeze(0)  # Remove batch and channel dimensions if present.
    else:
        seg_np = seg

    # Ensure seg_np has shape (H, W, D).
    assert len(seg_np.shape) == 3, f"Expected shape (H, W, D), but got {seg_np.shape}"

    # Compute the area of the tumor in each slice along the depth dimension.
    areas = [np.sum(seg_np[:, :, i]) for i in range(0, seg_np.shape[2], 1 + skip)]

    # Find the slice with the largest area.
    slice_idx = np.nonzero(areas)

    return slice_idx[0]

def make_dataloader(data_dir, shuffle, mode, batch_size=1):
    """Creates dataloader for provided data directory."""
    dataset = brats_dataset.BratsDataset(data_dir, mode=mode)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=1, pin_memory=True)
    return dataloader

def exp_decay_learning_rate(optimizer, epoch, init_lr, decay_rate):
    """Exponentially decays learning rate of optimizer at given epoch."""
    lr = init_lr * (decay_rate ** (epoch-1))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

def compute_loss(output, seg, loss_functs, loss_weights, device):
    """Computes weighted loss between model output and ground truth #, summed across each region."""
    loss = 0.
    for n, loss_function in enumerate(loss_functs):      
        temp = loss_function(output.to(device), seg.to(device))

        loss += temp * loss_weights[n]
    return loss

def train_one_epoch(model, optimizer, train_loader, loss_functions, loss_weights):
    """Performs one training loop of model according to given optimizer, loss functions and associated weights.

    Args:
        model: The PyTorch model to be trained.
        optimizer: The optimizer used for training.
        train_loader: The dataloader for training data.
        loss_functions: List of loss functions.
        loss_weights: List of associated weightings for each loss function.
        training_regions: String specifying whether 'disjoint' or 'overlapping' regions will be used for training.

    Returns:
        The average training loss over the epoch.
    """
    
    DEVICE = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    losses_over_epoch = []

    for _, imgs, seg in train_loader:

        # Clear cache at the start of each iteration.
        torch.cuda.empty_cache()

        model.train()

        # ROTATION SETUP
        theta = 0 #torch.empty(1).uniform_(-180, 180).item() # Calculate angle

        imgs = [img.to(DEVICE) for img in imgs] # img is B1HWD
        seg = seg.to(DEVICE)
        # = torch.Size([1, 1, 138, 202, 138])

        # Convert segmentation to binary mask.
        seg = seg_to_binary(seg) # seg is B1HWD - each voxel is either 0 (Not Tumour) or 1 (Tumour)
        # = torch.Size([1, 1, 138, 202, 138])

        # Find slices of the volume that contain tumours
        slices  = find_slices(seg).tolist()

        # Random selection of slices to train on 
        # if len(slices) > 10:
        #    slices = random.sample(slices, 10)
        # slices = random.sample(slices, 1)

        for slice_idx in tqdm(slices):
            # print(f"Slice index: {slice_idx}")
            seg_slice = seg[:, :, :, :, slice_idx]
            # Apply augmentation
            # seg_slice = augment(seg_slice, theta)

            # = torch.Size([1, 1, 138, 202])

            imgs_slices = [ img[:, :, :, :, slice_idx] for img in imgs]
            # = torch.Size([1, 1, 138, 202])

            # Convert every img to RGB by duplicates the single channel three times.
            imgs_slices = [torch.cat([img, img, img], dim=1) for img in imgs_slices] # img is B3HW
            # = torch.Size([1, 3, 138, 202])

            # Initialise the combined output mask to be the same shape as seg_slice.
            combined_output_mask = torch.zeros_like(seg_slice).to(DEVICE) # B1HW
            # = torch.Size([1, 1, 138, 202])


            # Generate the bounding box for the current slice.
            seg_mask = augment(seg_slice[0, 0, :, :].cpu().numpy(), theta)
            bbox_coord = np.array(generate_bbox(seg_mask, margin=0))

            del seg_mask

            # Process each scan type.
            for scan_type in range(4):
                
                img_slice = imgs_slices[scan_type].squeeze(0).permute(1, 2, 0).cpu().numpy()
                img_slice = augment(img_slice, theta)
                original_image_size = tuple(img_slice.shape[:2])
                # = (138, 202, 3)

                # Ensure img_slice is in uint8 format
                if img_slice.dtype != np.uint8:
                    img_slice = (img_slice * 255).astype(np.uint8)

                # Resizes the longest side to 1024, preserving aspect ratio.
                transform = ResizeLongestSide(model.image_encoder.img_size)
                img_slice = transform.apply_image(img_slice)
                # = (700, 1024, 3)

                # Convert to tensor, with batch dimension and permute to BCHW.
                img_slice = torch.as_tensor(img_slice, device=DEVICE).unsqueeze(0).permute(0, 3, 1, 2)
                # = torch.Size([1, 3, 700, 1024])

                # SAM Preprocessing of the image: Normalise pixel values and pad to a square input.
                img_slice = model.preprocess(img_slice).to(DEVICE) # Bx3x1024x1024

                input_size = tuple(img_slice.shape[-2:]) # (1024, 1024)

                # print(f"Scan: {scan_type}")
                    
                image_embedding = model.image_encoder(img_slice)

                with torch.no_grad():    

                    # apply_boxes expects prompt_box to be a numpy array shape Bx4.
                    box = transform.apply_boxes(bbox_coord, original_image_size)
                    box_torch = torch.as_tensor(box, dtype=torch.float, device=DEVICE)[None, :]

                    sparse_embeddings, dense_embeddings = model.prompt_encoder(
                        points=None,
                        boxes=box_torch,
                        masks=None,
                    )

                low_res_masks, __ = model.mask_decoder(
                    image_embeddings=image_embedding,
                    image_pe=model.prompt_encoder.get_dense_pe(),
                    sparse_prompt_embeddings=sparse_embeddings,
                    dense_prompt_embeddings=dense_embeddings,
                    multimask_output=False,
                )
                # = torch.Size([1, 1, 256, 256])

                # Remove padding and upscale masks to the original image size.
                upscaled_masks = model.postprocess_masks(low_res_masks, input_size, original_image_size) # B1HW
                # = torch.Size([1, 1, 138, 202])

                slice_output = normalize(threshold(upscaled_masks, 0.0, 0)).to(DEVICE)
                slice_output.requires_grad_(True) # B1HW
                # = torch.Size([1, 1, 138, 202])

                # Combine the current slice output with the combined mask using a union operation.
                combined_output_mask = torch.max(combined_output_mask, slice_output)

                # Delete tensors to free up memory.
                del box, box_torch, img_slice, image_embedding, sparse_embeddings, dense_embeddings, low_res_masks, upscaled_masks, slice_output
                torch.cuda.empty_cache()

            # Ensure combined_output_mask and seg_slice are the same shape and device
            assert combined_output_mask.shape == seg_slice.shape, f"Shape mismatch: {combined_output_mask.shape} vs {seg_slice.shape}"
            combined_output_mask = combined_output_mask.to(seg_slice.device)
            seg_slice = seg_slice.to(DEVICE)

            # Compute weighted loss, summed across each region.
            loss = compute_loss(combined_output_mask, seg_slice, loss_functions, loss_weights, DEVICE)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            losses_over_epoch.append(loss.detach().cpu())

            # Delete output to free up memory.
            del combined_output_mask
            torch.cuda.empty_cache()

    # Compute loss from the epoch.
    average_epoch_loss = np.mean(losses_over_epoch)
    return average_epoch_loss

def validate (model, valid_loader, loss_functions, loss_weights):
    
    print("Validation loop")
    DEVICE = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    predictor = SamPredictor(model)
    dice = DiceMetric(include_background=False, reduction="mean_batch")
    losses = []
    dsc = []

    with torch.no_grad():
        for file_name, imgs, seg in  valid_loader:
            model.eval()

            imgs = [img.to(DEVICE) for img in imgs] # img is B1HWD
            seg = seg.to(DEVICE)
            # = torch.Size([1, 1, 138, 202, 138])

            # Convert segmentation to binary mask.
            seg = seg_to_binary(seg) # seg is B1HWD - each voxel is either 0 (Not Tumour) or 1 (Tumour)
            # = torch.Size([1, 1, 138, 202, 138])

            # Convert every img to RGB by duplicates the single channel three times.
            imgs = [torch.cat([img, img, img], dim=1) for img in imgs]            

            # Initialise the output tensor to be the same shape as seg_train.
            output = torch.zeros_like(seg).to(DEVICE)

            # List slices containing tumours
            slices  = find_slices(seg).tolist()

            print("Current Image: ", file_name)
            # Iterate through each slice along the depth dimension, i.e. index 4.
            for slice_idx in tqdm(slices):

                # Extract the 2D binary mask for the current slice.
                seg_slice = seg[:, :, :, :, slice_idx]

                # Initialise the combined output mask to be the same shape as seg_slice.
                combined_output_slice = torch.zeros_like(seg_slice).to(DEVICE)
                # = torch.Size([1, 1, 138, 202])

                # Generate the bounding box for the current slice.
                bbox_coord = np.array(generate_bbox(seg_slice[0, 0, :, :].cpu().numpy(), margin=0))

                # Process each scan type.
                for scan_type in range(4):
                    
                    img_slice = imgs[scan_type][0, :, :, :, slice_idx].permute(1, 2, 0).cpu().numpy()
                    # = (138, 202, 3)

                    # Ensure img_slice is in uint8 format
                    if img_slice.dtype != np.uint8:
                        img_slice = (img_slice * 255).astype(np.uint8)

                    # Set the image for prediction.
                    predictor.set_image(img_slice, "RGB")
                    
                    # Predict using the bounding box.
                    slice_output, scr, logit = predictor.predict(
                        box=bbox_coord,
                        multimask_output=False,
                    )
                    # = (1, 138, 202)

                    # Convert slice_output to tensor.
                    slice_output = torch.tensor(slice_output, device=DEVICE).unsqueeze(0)

                    # Combine the current slice output with the combined mask using a union operation.
                    combined_output_slice = torch.max(combined_output_slice, slice_output)

                # Print tensors to view change
                # print("Output slice")
                # print_tensor(combined_output_slice.squeeze(), bbox_coord)
                # print("True mask")
                # print_tensor(seg_slice.squeeze(), bbox_coord)

                # Add the slice_output to the correct slice in output volume
                output[0, 0, :, :, slice_idx] = combined_output_slice

            # Compute weighted loss, summed across each training region.
            val_loss = compute_loss(output, seg, loss_functions, loss_weights, DEVICE)
            losses.append(val_loss.detach().cpu())

            preds = (output > 0.5).float()

            # Compute metrics between seg_eval and preds_eval.
            score = dice(y_pred=preds, y=seg)
            dsc.append(score.item())
            
            diy = diy_dice(preds, seg)
            print("DSC: ", score.item(), "diy_dsc: ", diy)

    # Compute and report validation loss.
    average_val_loss = np.mean(losses)
    print(f'Validation completed. Average validation loss = {average_val_loss}')

    # Aggregate and report the Dice scores.
    mean_dice = np.mean(dsc)
    form_dice = dice.aggregate().item()
    print(f'Dice Score = {mean_dice} \n Alt formula = {form_dice}')

    return average_val_loss, mean_dice

def diy_dice(tensor1, tensor2):
    """
    Calculates the Dice coefficient between two 3D tensors.

    Args:
    tensor1: The first 3D tensor.
    tensor2: The second 3D tensor.

    Returns:
    The Dice coefficient between the two tensors.
    """
    # Ensure tensors are binary (0 or 1)
    tensor1 = (tensor1 > 0).float()
    tensor2 = (tensor2 > 0).float()

    # Calculate intersection and union
    intersection = torch.sum(tensor1 * tensor2)
    union = torch.sum(tensor1) + torch.sum(tensor2)

    # Handle potential division by zero
    if union == 0:
        return 0.0

    # Calculate Dice coefficient
    dice = (2.0 * intersection) / union
    return dice.item()

def print_tensor(tensor, box):
    """Prints the values in a tensor within a bounding box.

    Args:
        tensor: The tensor to print values from.
        box_coords: A tuple of (x0, y0, x1, y1) coordinates defining the bounding box.
    """
    x0, y0, x1, y1 = box
    #   for y in range(y0, y1 + 1):
    #     for x in range(x0, x1 + 1):
    #         print(tens[y, x], end=" ")
    #     print()
    bbox_values = tensor[y0:y1, x0:x1]
    print(bbox_values)


def freeze_layers(model, frozen_layers):
    """Freezes specified model layers. Afterwards parameters in these layers will not be updated when training.

    Args:
        model: The model to be trained.
        frozen_layers: List of strings specifying model layers.
    """

    for name, param in model.named_parameters():
        needs_freezing = False
        for layer in frozen_layers:
            if layer in name:
                needs_freezing = True
                break
        if needs_freezing:
            print(f'Freezing parameter {name}.')
            param.requires_grad = False

def check_frozen(model, frozen_layers):
    """Iterates through model layers and checks whether specified layers are frozen.

    Args:
        model: The model to be trained.
        frozen_layers: List of strings specifying model layers.
    """
    for name, param in model.named_parameters():
        needs_freezing = False
        for layer in frozen_layers:
            if layer in name:
                needs_freezing = True
                break
        if needs_freezing:
            if param.requires_grad:
                print(f'Warning! Param {name} should not require grad but does.')
                break
            else:
                print(f'Parameter {name} is frozen.')

def initialise_from_sam_pretrained(model, pretrained_path : str, rank = 0):
    """Initialises the model from SAM's pretrained weights.

    Args:
        model: The PyTorch model to be trained.
        pretrained_path: The path to SAM's pretrained weights.
    
    Returns:
        The model initialized with SAM's pretrained weights.
    """
    print(f'Initialising model from SAM\'s pretrained weights: {pretrained_path}')
    
    # pretrained_state_dict = torch.load(pretrained_path)
    # model.load_state_dict(pretrained_state_dict)
    if (pretrained_path.endswith("tar")):
        base_sam = build_sam_vit_b()
        pretrained_state_dict = torch.load(pretrained_path, map_location= torch.device("cpu"))
        base_sam.load_state_dict(pretrained_state_dict["model_sd"])
    else:
        base_sam = build_sam_vit_b(pretrained_path)
    sam_lora = LoRA_sam(base_sam, rank)
    
    return sam_lora.sam

def load_from_checkpoint(model, optimizer, checkpoint_path, train_with_val=False):
    """Loads the model and optimizer state from a training checkpoint.

    Args:
        model: The PyTorch model to be trained.
        optimizer: The optimizer used for training.
        checkpoint_path: The path to the latest model checkpoint.
        train_with_val: If True, also returns best saved validation loss and dice. Defaults to False.

    Returns:
        The starting epoch number.
        If 'train_with_val' is True, also returns best saved validation loss and dice.
    """
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"No checkpoint found at {checkpoint_path}")

    print('Training checkpoint found. Loading checkpoint...')
    checkpoint = torch.load(checkpoint_path)
    
    # Print all keys in the checkpoint
    print("Keys in the checkpoint:")
    for key in checkpoint.keys():
        print(key)

    epoch_start = checkpoint['epoch'] + 1
    model.load_state_dict(checkpoint['model_sd'])
    optimizer.load_state_dict(checkpoint['optim_sd'])

    if train_with_val:
        best_vloss = checkpoint.get('vloss', float('inf'))
        best_dice = checkpoint.get('dice', 0)
        return epoch_start, best_vloss, best_dice
    
    return epoch_start

def load_or_initialize_training(model, optimizer, latest_ckpt_path, sam_pretrained_path, rank = 0, train_with_val=False):
    """Loads training checkpoint if it exists, or initializes training from SAM's pretrained weights.

    Args:
        model: The PyTorch model to be trained.
        optimizer: The optimizer used for training.
        latest_ckpt_path: The path to the latest model checkpoint.
        sam_pretrained_path: The path to SAM's pretrained weights.
        train_with_val: If True, also returns best saved validation loss and dice. Defaults to False.

    Returns:
        The starting epoch number.
        If 'train_with_val' is True, also returns best saved validation loss and dice.
    """
    if os.path.exists(latest_ckpt_path):
        return load_from_checkpoint(model, optimizer, latest_ckpt_path, train_with_val)
    else:
        model = initialise_from_sam_pretrained(model, sam_pretrained_path, rank)
        epoch_start = 1
        if train_with_val:
            best_vloss = float('inf')
            best_dice = 0
            return epoch_start, best_vloss, best_dice
        return epoch_start