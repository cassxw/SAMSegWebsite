import os
import shutil

# Define the source and destination directories
source_dir = '/home/cassxw/SAMSeg/datasets/BraTS-MEN-Train'
validate_dir = '/home/cassxw/SAMSeg/datasets/BraTS-MEN-Validate'
test_dir = '/home/cassxw/SAMSeg/datasets/BraTS-MEN-Test'

# Create destination directories if they don't exist
os.makedirs(validate_dir, exist_ok=True)
os.makedirs(test_dir, exist_ok=True)

# Get a sorted list of subfolders in the source directory
subfolders = sorted(os.listdir(source_dir))

# Split the subfolders into training, validation, and test sets
train_subfolders = subfolders[:680]
validate_subfolders = subfolders[680:880]
test_subfolders = subfolders[880:1000]

# Move validation subfolders
for subfolder in validate_subfolders:
    shutil.move(os.path.join(source_dir, subfolder), validate_dir)

# Move test subfolders
for subfolder in test_subfolders:
    shutil.move(os.path.join(source_dir, subfolder), test_dir)

print("Dataset split completed successfully.")
