# Source: https://github.com/KurtLabUW/brats2023_updated/blob/master/model_routines/train.py
# Date: July 4, 2024

import os
import torch 
from torch import optim
import csv

from model_utils_fix import load_or_initialize_training, make_dataloader, exp_decay_learning_rate, train_one_epoch, validate, check_frozen, freeze_layers

def train(data_dir, model, rank, loss_functions, loss_weights, init_lr, max_epoch, out_dir=None, trained=None, decay_rate=0.995, backup_interval=2, batch_size=1):
    """Runs basic training routine.

    Args:
        data_dir: Directory of training data.
        model: The PyTorch model to be trained.
        loss_functions: List of loss functions to be used for training.
        loss_weights: List of weights corresponding to each loss function.
        init_lr: Initial value of learning rate.
        max_epoch: Maximum number of epochs to train for.
        training_regions: Whether training on 'disjoint' or 'overlapping' regions. Defaults to 'overlapping'.
        out_dir: The directory to save model checkpoints and loss values. Defaults to None.
        decay_rate: Rate at which to decay the learning rate. Defaults to 0.995.
        backup_interval: How often to save a backup checkpoint. Defaults to 10.
        batch_size: Batch size of dataloader. Defaults to 1.
    """
    # Set up directories and paths.
    if out_dir is None:
        out_dir = os.getcwd()
    latest_ckpt_path = os.path.join(out_dir, 'latest_ckpt.pth.tar')
    training_loss_path = os.path.join(out_dir, 'training_loss.csv')
    backup_ckpts_dir = os.path.join(out_dir, 'backup_ckpts')
    if not os.path.exists(backup_ckpts_dir):
        os.makedirs(backup_ckpts_dir)
        os.system(f'chmod a+rwx {backup_ckpts_dir}')
    
    optimizer = optim.Adam(model.image_encoder.parameters(), lr=init_lr, weight_decay=0, amsgrad=True)

    # Check if training for first time or continuing from a saved checkpoint.
    epoch_start = load_or_initialize_training(model, optimizer, latest_ckpt_path, trained, rank)

    # Ensure correct params are frozen before training
    # list_param = model.image_encoder.named_parameters()
    # for name, param in model.named_parameters():
    #     print(f"Parameter name: {name}, requires gradient: {param.requires_grad}")

    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print("Total params: ", total_params, "\nTrainable params: ", trainable_params)

    img_params = sum(p.numel() for p in model.image_encoder.parameters())
    prt_params = sum(p.numel() for p in model.prompt_encoder.parameters())
    msk_params = sum(p.numel() for p in model.mask_decoder.parameters())
    print("Image params: ", img_params, "\nPrompt params: ", prt_params, "\nMask params: ", msk_params)
    print("--------------------------------------------------------------")
    train_loader = make_dataloader(data_dir, shuffle=True, mode='train', batch_size=batch_size)
    val_loader = make_dataloader(val_dir, shuffle=False, mode='train', batch_size=batch_size)

    print('Training starts.')
    for epoch in range(epoch_start, max_epoch+1):
        print(f'Starting epoch {epoch}...')

        exp_decay_learning_rate(optimizer, epoch, init_lr, decay_rate)

        average_epoch_loss = train_one_epoch(model, optimizer, train_loader, loss_functions, loss_weights)

        val_loss = 0
        avg_dice = 0
        if epoch % (2) == 0:
            val_loss, avg_dice = validate(model, val_loader, loss_functions, loss_weights)

        # Save and report loss from the epoch.
        #save_metrics(training_loss_path, epoch, average_epoch_loss, val_loss, avg_dice)
        print(f'Epoch {epoch} completed. Average loss = {average_epoch_loss}.')

        print('Saving model checkpoint...')
        checkpoint = {
            'epoch': epoch,
            'model_sd': model.state_dict(),
            'optim_sd': optimizer.state_dict(),
            'model': model,
            'loss_functions': loss_functions,
            'loss_weights': loss_weights,
            'init_lr': init_lr,
            'decay_rate': decay_rate
        }
        #torch.save(checkpoint, latest_ckpt_path)
        if epoch % backup_interval == 0:
            print('Saving backup checkpoint...')
            #torch.save(checkpoint, os.path.join(backup_ckpts_dir, f'epoch{epoch}.pth.tar'))
        print('Checkpoint saved successfully.')

def save_metrics(pathname, epoch, tloss, vloss, avg_dice):
    with open(pathname, mode='a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        if epoch == 1:
            writer.writerow(['Epoch', 'Training Loss', 'Validation Loss', 'Dice'])
        writer.writerow([epoch, tloss, vloss, avg_dice])

if __name__ == '__main__':

    from segment_anything import sam_model_registry
    from src.lora import LoRA_sam
    import torch.nn as nn

    data_dir = '/home/peter/Documents/Code/samseg/src/testSamples/MEDIUM_Samples' # "/home/peter/BraTS-MEN-dumb" #
    val_dir = '/home/peter/Documents/Code/samseg/src/testSamples/MEDIUM_Samples' #'/home/peter/BraTS-MEN-dumb'
    trained_pth = "/home/peter/Documents/Code/samseg/src/sam_vit_b_01ec64.pth"

    DEVICE = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    RANK = 16
    sam = sam_model_registry['vit_b'](checkpoint=None)

    #ADDED LORA
    sam_lora = LoRA_sam(sam, RANK)
    model = sam_lora.sam
    model.to(DEVICE)
    
    loss_functions = [nn.MSELoss(), nn.CrossEntropyLoss()]
    loss_weights = [0.4, 0.7]
    lr = 6e-3
    max_epoch = 1
    out_dir = './train-out'

    train(data_dir, model, RANK, loss_functions, loss_weights, lr, max_epoch, trained=trained_pth, out_dir=out_dir)