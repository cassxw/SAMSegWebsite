# Source: https://github.com/KurtLabUW/brats2023_updated/blob/master/utils/model_utils.py
# Date: July 4, 2024

import os
import numpy as np
import torch
from torch.utils.data import DataLoader

import brats_dataset

from general_utils import seg_to_binary, generate_bbox
from plot import max_slice
from preprocess import augment

from torch.nn.functional import threshold, normalize

from segment_anything.utils.transforms import ResizeLongestSide

def make_dataloader(data_dir, shuffle, mode, batch_size=1):
    """Creates dataloader for provided data directory."""
    dataset = brats_dataset.BratsDataset(data_dir, mode=mode)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=1, pin_memory=True)
    return dataloader

def exp_decay_learning_rate(optimizer, epoch, init_lr, decay_rate):
    """Exponentially decays learning rate of optimizer at given epoch."""
    lr = init_lr * (decay_rate ** (epoch-1))
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

def compute_loss(output, seg, loss_functs, loss_weights, device):
    """Computes weighted loss between model output and ground truth #, summed across each region."""
    loss = 0.
    for n, loss_function in enumerate(loss_functs):      
        # temp = 0
        # for i in range(3):
        #     # temp += loss_function(output[:,i:i+1].to(device), seg[:,i:i+1].to(device))

        temp = loss_function(output.to(device), seg.to(device))

        loss += temp * loss_weights[n]
    return loss

def train_one_epoch(model, optimizer, train_loader, loss_functions, loss_weights, training_regions):
    """Performs one training loop of model according to given optimizer, loss functions and associated weights.

    Args:
        model: The PyTorch model to be trained.
        optimizer: The optimizer used for training.
        train_loader: The dataloader for training data.
        loss_functions: List of loss functions.
        loss_weights: List of associated weightings for each loss function.
        training_regions: String specifying whether 'disjoint' or 'overlapping' regions will be used for training.

    Returns:
        The average training loss over the epoch.
    """
    
    DEVICE = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    losses_over_epoch = []

    for _, imgs, seg in train_loader:

        # Clear cache at the start of each iteration.
        torch.cuda.empty_cache()

        model.train()

        # ROTATION SETUP
        theta = 0 #torch.empty(1).uniform_(-180, 180).item() # Calculate angle

        # Having an issue with not enough memory for all slices
        # Trying the training on just the max_slice
        imgs = [img.to(DEVICE) for img in imgs] # img is B1HWD
        seg = seg.to(DEVICE)
        # = torch.Size([1, 1, 138, 202, 138])

        # Convert segmentation to binary mask.
        seg = seg_to_binary(seg) # seg is B1HWD - each voxel is either 0 (Not Tumour) or 1 (Tumour)
        # = torch.Size([1, 1, 138, 202, 138])

        # Extract the 2D binary mask for the max slice
        slice_idx = max_slice(seg)

        seg_slice = seg[:, :, :, :, slice_idx]
        # Apply augmentation
        # seg_slice = augment(seg_slice, theta)

        # = torch.Size([1, 1, 138, 202])

        imgs_slices = [ img[:, :, :, :, slice_idx] for img in imgs]
        # = torch.Size([1, 1, 138, 202])

        # Convert every img to RGB by duplicates the single channel three times.
        imgs_slices = [torch.cat([img, img, img], dim=1) for img in imgs_slices] # img is B3HW
        # = torch.Size([1, 3, 138, 202])

        # Initialise the combined output mask to be the same shape as seg_slice.
        combined_output_mask = torch.zeros_like(seg_slice).to(DEVICE) # B1HW
        # = torch.Size([1, 1, 138, 202])


        # Generate the bounding box for the current slice.
        seg_mask = augment(seg_slice[0, 0, :, :].cpu().numpy(), theta)
        bbox_coord = np.array(generate_bbox(seg_mask, margin=0))

        del imgs, seg, seg_mask

        # Process each scan type.
        for scan_type in range(4):
            
            img_slice = imgs_slices[scan_type].squeeze(0).permute(1, 2, 0).cpu().numpy()
            img_slice = augment(img_slice, theta)
            original_image_size = tuple(img_slice.shape[:2])
            # = (138, 202, 3)

            # Ensure img_slice is in uint8 format
            if img_slice.dtype != np.uint8:
                img_slice = (img_slice * 255).astype(np.uint8)

            # Resizes the longest side to 1024, preserving aspect ratio.
            transform = ResizeLongestSide(model.image_encoder.img_size)
            img_slice = transform.apply_image(img_slice)
            # = (700, 1024, 3)

            # Convert to tensor, with batch dimension and permute to BCHW.
            img_slice = torch.as_tensor(img_slice, device=DEVICE).unsqueeze(0).permute(0, 3, 1, 2)
            # = torch.Size([1, 3, 700, 1024])

            # SAM Preprocessing of the image: Normalise pixel values and pad to a square input.
            img_slice = model.preprocess(img_slice).to(DEVICE) # Bx3x1024x1024

            input_size = tuple(img_slice.shape[-2:]) # (1024, 1024)

            print(f"Scan: {scan_type}")
                
            #with torch.no_grad():
            image_embedding = model.image_encoder(img_slice)

            # apply_boxes expects prompt_box to be a numpy array shape Bx4.
            box = transform.apply_boxes(bbox_coord, original_image_size)
            box_torch = torch.as_tensor(box, dtype=torch.float, device=DEVICE)[None, :]

            sparse_embeddings, dense_embeddings = model.prompt_encoder(
                points=None,
                boxes=box_torch,
                masks=None,
            )

            low_res_masks, __ = model.mask_decoder(
                image_embeddings=image_embedding,
                image_pe=model.prompt_encoder.get_dense_pe(),
                sparse_prompt_embeddings=sparse_embeddings,
                dense_prompt_embeddings=dense_embeddings,
                multimask_output=False,
            )
            # = torch.Size([1, 1, 256, 256])

            # Remove padding and upscale masks to the original image size.
            upscaled_masks = model.postprocess_masks(low_res_masks, input_size, original_image_size) # B1HW
            # = torch.Size([1, 1, 138, 202])

            slice_output = normalize(threshold(upscaled_masks, 0.0, 0)).to(DEVICE)
            slice_output.requires_grad_(True) # B1HW
            # = torch.Size([1, 1, 138, 202])

            # See about incorportating KurtLab's post-processing functions?

            # Combine the current slice output with the combined mask using a union operation.
            combined_output_mask = torch.max(combined_output_mask, slice_output)

            # Delete tensors to free up memory.
            del box, box_torch, img_slice, image_embedding, sparse_embeddings, dense_embeddings, low_res_masks, upscaled_masks, slice_output
            torch.cuda.empty_cache()

        # Ensure combined_output_mask and seg_slice are the same shape and device
        assert combined_output_mask.shape == seg_slice.shape, f"Shape mismatch: {combined_output_mask.shape} vs {seg_slice.shape}"
        combined_output_mask = combined_output_mask.to(seg_slice.device)
        seg_slice = seg_slice.to(DEVICE)

        # Compute weighted loss, summed across each region.
        loss = compute_loss(combined_output_mask, seg_slice, loss_functions, loss_weights, DEVICE)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        losses_over_epoch.append(loss.detach().cpu())

        # Delete output to free up memory.
        del imgs, seg, combined_output_mask
        torch.cuda.empty_cache()

    # Compute loss from the epoch.
    average_epoch_loss = np.mean(losses_over_epoch)
    return average_epoch_loss

def freeze_layers(model, frozen_layers):
    """Freezes specified model layers. Afterwards parameters in these layers will not be updated when training.

    Args:
        model: The model to be trained.
        frozen_layers: List of strings specifying model layers.
    """

    for name, param in model.named_parameters():
        needs_freezing = False
        for layer in frozen_layers:
            if layer in name:
                needs_freezing = True
                break
        if needs_freezing:
            print(f'Freezing parameter {name}.')
            param.requires_grad = False

def check_frozen(model, frozen_layers):
    """Iterates through model layers and checks whether specified layers are frozen.

    Args:
        model: The model to be trained.
        frozen_layers: List of strings specifying model layers.
    """
    for name, param in model.named_parameters():
        needs_freezing = False
        for layer in frozen_layers:
            if layer in name:
                needs_freezing = True
                break
        if needs_freezing:
            if param.requires_grad:
                print(f'Warning! Param {name} should not require grad but does.')
                break
            else:
                print(f'Parameter {name} is frozen.')

# Example parts of unet_3d model to freeze
# 'encoder': ['Conv1', 'Conv2', 'Conv3', 'Conv4', 'Conv5', 'Conv6', 'Conv7'],
# 'decoder': ['Up6', 'Up_conv6', 'Up5', 'Up_conv5', 'Up4', 'Up_conv4', 'Up3', 'Up_conv3', 'Conv_1x13', 'Up2', 'Up_conv2', 'Conv_1x12', 'Up1', 'Up_conv1', 'Conv_1x11'],
# 'middle' : ['Conv5', 'Conv6', 'Conv7', 'Up6', 'Up_conv6', 'Up5', 'Up_conv5', 'Up4', 'Up_conv4'],
# 'none' : [],
# 'deep_decoder': ['Up6', 'Up_conv6', 'Up5', 'Up_conv5', 'Up4', 'Up_conv4']

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def initialise_from_sam_pretrained(model, pretrained_path):
    """Initialises the model from SAM's pretrained weights.

    Args:
        model: The PyTorch model to be trained.
        pretrained_path: The path to SAM's pretrained weights.
    
    Returns:
        The model initialized with SAM's pretrained weights.
    """
    print(f'Initialising model from SAM\'s pretrained weights: {pretrained_path}')
    pretrained_state_dict = torch.load(pretrained_path)
    model.load_state_dict(pretrained_state_dict)
    return model

def load_from_checkpoint(model, optimizer, checkpoint_path, train_with_val=False):
    """Loads the model and optimizer state from a training checkpoint.

    Args:
        model: The PyTorch model to be trained.
        optimizer: The optimizer used for training.
        checkpoint_path: The path to the latest model checkpoint.
        train_with_val: If True, also returns best saved validation loss and dice. Defaults to False.

    Returns:
        The starting epoch number.
        If 'train_with_val' is True, also returns best saved validation loss and dice.
    """
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(f"No checkpoint found at {checkpoint_path}")

    print('Training checkpoint found. Loading checkpoint...')
    checkpoint = torch.load(checkpoint_path)
    
    # Print all keys in the checkpoint
    print("Keys in the checkpoint:")
    for key in checkpoint.keys():
        print(key)
        # epoch
        # model_sd
        # optim_sd
        # model
        # loss_functions
        # loss_weights
        # init_lr
        # training_regions
        # decay_rate

    epoch_start = checkpoint['epoch'] + 1
    model.load_state_dict(checkpoint['model_sd'])
    optimizer.load_state_dict(checkpoint['optim_sd'])

    if train_with_val:
        best_vloss = checkpoint.get('vloss', float('inf'))
        best_dice = checkpoint.get('dice', 0)
        return epoch_start, best_vloss, best_dice
    
    return epoch_start

def load_or_initialize_training(model, optimizer, latest_ckpt_path, sam_pretrained_path, train_with_val=False):
    """Loads training checkpoint if it exists, or initializes training from SAM's pretrained weights.

    Args:
        model: The PyTorch model to be trained.
        optimizer: The optimizer used for training.
        latest_ckpt_path: The path to the latest model checkpoint.
        sam_pretrained_path: The path to SAM's pretrained weights.
        train_with_val: If True, also returns best saved validation loss and dice. Defaults to False.

    Returns:
        The starting epoch number.
        If 'train_with_val' is True, also returns best saved validation loss and dice.
    """
    if os.path.exists(latest_ckpt_path):
        return load_from_checkpoint(model, optimizer, latest_ckpt_path, train_with_val)
    else:
        #model = #initialise_from_sam_pretrained(model, sam_pretrained_path)
        epoch_start = 1
        if train_with_val:
            best_vloss = float('inf')
            best_dice = 0
            return epoch_start, best_vloss, best_dice
        return epoch_start