# Source: https://github.com/KurtLabUW/brats2023_updated/blob/master/processing/plot.py
# Date: July 5, 2024

import numpy as np
import matplotlib.pyplot as plt

from general_utils import generate_bbox

def max_slice(seg):
    # """Finds the slice (in the z-direction) of a segmentation with the most tumour voxels."""
    # one_hot_encoded = np.where(seg != 0, 1, 0)
    # slice_sums = np.sum(one_hot_encoded, axis=(0,1))
    # max_index = np.argmax(slice_sums)

    """Finds the slice with the largest cross-sectional area of the tumor.

    Args:
        seg: The 3D segmentation tensor with shape [B, 1, H, W, D].

    Returns:
        The index of the slice with the largest cross-sectional area of the tumor.
    """
    
    # Ensure seg is a numpy array.
    if not isinstance(seg, np.ndarray):
        seg_np = seg.cpu().numpy()
        seg_np = seg_np.squeeze(0).squeeze(0)  # Remove batch and channel dimensions if present.
    else:
        seg_np = seg

    # Ensure seg_np has shape (H, W, D).
    assert len(seg_np.shape) == 3, f"Expected shape (H, W, D), but got {seg_np.shape}"

    # Compute the area of the tumor in each slice along the depth dimension.
    areas = [np.sum(seg_np[:, :, i]) for i in range(seg_np.shape[2])]

    # Find the slice with the largest area.
    largest_slice_idx = np.argmax(areas)

    return largest_slice_idx

def plot_slices(images=None, seg=None, pred=None):
    """For a given subject, plots the same slice of MRI images, ground truth, and predicted segmentations.

    Args:
        images: List (one for each of the four modalities) of MRI image tensors of shape HWD.
        seg: Ground truth segmentation tensor of shape HWD.
        pred: Predicted segmentation tensor of shape HWD.

    Returns:
        Matplotlib figure containing the plot.
    """

    nslice = max_slice(seg)

    seg_slice = seg[:, :, nslice]
    pred_slice = pred[:, :, nslice]

    bbox = np.array(generate_bbox(seg_slice))

    fig, axes = plt.subplots(1, 6, figsize=(30, 5))

    # Plot MRI images.
    for i, suffix in enumerate(['t1c', 't1n', 't2f', 't2w']):
        axes[i].imshow(images[i][:, :, nslice], cmap='gray')
        axes[i].set_title(f'{suffix}')
        axes[i].axis('off')
        show_box(bbox, axes[i])
        # show_mask(seg_slice, axes[i], colour=[0, 1, 0, 0.6])                # Green for GT mask.
        show_mask(pred_slice, axes[i], colour=[30/255, 144/255, 255/255, 1])  # Blue for predicted mask.

    # Plot ground truth segmentation
    axes[4].imshow(seg_slice, cmap='gray', vmin=0, vmax=1)
    axes[4].set_title('Ground Truth Segmentation')
    axes[4].axis('off')
    show_box(bbox, axes[4])

    # Plot predicted segmentation
    axes[5].imshow(pred_slice, cmap='gray', vmin=0, vmax=1)
    axes[5].set_title('Predicted Segmentation')
    axes[5].axis('off')
    show_box(bbox, axes[5])

    plt.tight_layout()
    return fig

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Helper functions for visualization adapted from 
# https://colab.research.google.com/drive/1F6uRommb3GswcRlPZWpkAQRMVNdVH7Ww?usp=sharing#scrollTo=sH6NorejpTii
def show_mask(mask, ax, colour=False):
    """
    Display mask on matplotlib axis.
    
    Args:
        mask (numpy array): The mask array to be displayed.
        ax (matplotlib axis): The axis to display the mask on.
        colour (list or None): The colour of the mask. If None, defaults to red.
    """
    if colour is None:
        # Default to red.
        colour = np.array([1, 0, 0, 0.6])

    mask = mask.astype(float)
    mask_image = np.expand_dims(mask, axis=-1) * colour
    ax.imshow(mask_image)

def show_box(box, ax, colour='red'):
    """
    Display bounding box on matplotlib axis.
    
    Args:
        box (list): The bounding box coordinates [x0, y0, x1, y1].
        ax (matplotlib axis): The axis to display the bounding box on.
        colour (str): The colour of the bounding box.
    """
    x0, y0 = box[0], box[1]
    w, h = box[2] - box[0], box[3] - box[1]
    ax.add_patch(plt.Rectangle((x0, y0), w, h, edgecolor=colour, facecolor=(0,0,0,0), lw=2))